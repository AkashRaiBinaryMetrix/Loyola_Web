<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserCommunity;
use App\Models\Community;
use App\Models\Category;
use App\Models\SubCategory;
use DB;
use File;
use Intervention\Image\Facades\Image;

class CommunityController extends Controller
{
    public function add_community(Request $request)
    {
        if($request->isMethod('post'))
        {
            date_default_timezone_set('UTC');
            $usercommunity=new UserCommunity;
            $usercommunity->user_id=\Session::get('user')->id;
            $usercommunity->name=$request->name;
            $usercommunity->description=$request->description;
            $checkcomm=Community::where('title',$request->name)->first();
            if(!empty($checkcomm))
            {
              return redirect()->back()->with('error','This community already exist!');
            }
            if(!empty($request->image))
            {
                $originalImage= $request->file('image');
                $thumbnailImage = Image::make($originalImage);
                $thumbnailPath = public_path().'/community_image/';
                if (! File::exists($thumbnailPath))
                {
                    File::makeDirectory($thumbnailPath, 0777, true, true);
                }
                $rand=rand(1111,9999);
                $originalPath = public_path().'/community/';
                if (! File::exists($originalPath))
                {
                    File::makeDirectory($originalPath, 0777, true, true);
                }
                $thumbnailImage->save($originalPath.'community'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension());
                $thumbnailImage->resize(100,100);
                $thumbnailImage->save($thumbnailPath.'community'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension());
                $usercommunity->image='community'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension();
            }
            if(!empty($request->cover_image))
            {
                 
                $originalImage= $request->file('cover_image');
                $thumbnailImage = Image::make($originalImage);
                $thumbnailPath = public_path().'/community_image/';
                if (! File::exists($thumbnailPath))
                {
                    File::makeDirectory($thumbnailPath, 0777, true, true);
                }
                $rand=rand(1111,9999);
                $originalPath = public_path().'/community/';
                if (! File::exists($originalPath))
                {
                    File::makeDirectory($originalPath, 0777, true, true);
                }
                $thumbnailImage->save($originalPath.'community'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension());
                $thumbnailImage->resize(800,350);
                $thumbnailImage->save($thumbnailPath.'community'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension());
                $usercommunity->cover_image='community'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension();
            }
            $usercommunity->created_at=\Carbon\Carbon::now();
            $usercommunity->updated_at=\Carbon\Carbon::now();
            $usercommunity->save();

            $community=new Community;
            $community->user_community=\Session::get('user')->id;
            $community->title=$request->name;
            $community->description=$request->description;
            $checkcomm=Community::where('title',$request->name)->first();
            if(!empty($checkcomm))
            {
              return redirect()->back()->with('error','This community already exist!');
            }
            if(!empty($request->image))
            {
                $originalImage= $request->file('image');
                $thumbnailImage = Image::make($originalImage);
                $thumbnailPath = public_path().'/community_image/';
                if (! File::exists($thumbnailPath))
                {
                    File::makeDirectory($thumbnailPath, 0777, true, true);
                }
                $rand=rand(1111,9999);
                $originalPath = public_path().'/community/';
                if (! File::exists($originalPath))
                {
                    File::makeDirectory($originalPath, 0777, true, true);
                }
                $thumbnailImage->save($originalPath.'community'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension());
                $thumbnailImage->resize(100,100);
                $thumbnailImage->save($thumbnailPath.'community'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension());
                $community->image='community'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension();
            }
            if(!empty($request->cover_image))
            {
                $originalImage= $request->file('cover_image');
                $thumbnailImage = Image::make($originalImage);
                $thumbnailPath = public_path().'/community_image/';
                if (! File::exists($thumbnailPath))
                {
                    File::makeDirectory($thumbnailPath, 0777, true, true);
                }
                $rand=rand(1111,9999);
                $originalPath = public_path().'/community/';
                if (! File::exists($originalPath))
                {
                    File::makeDirectory($originalPath, 0777, true, true);
                }
                $thumbnailImage->save($originalPath.'community'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension());
                $thumbnailImage->resize(800,350);
                $thumbnailImage->save($thumbnailPath.'community'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension());
                $community->cover_image='community'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension();
            }
            $community->created_at=\Carbon\Carbon::now();
            $community->updated_at=\Carbon\Carbon::now();
            $community->save();

                  $activity['post_id']=$community->id;
                  $activity['like_id']='';
                  $activity['user_id']=\Session::get('user')->id;
                  $activity['status']='You requested to approve a community';
                  $activity['created_at']=\Carbon\Carbon::now();
                  $activity['updated_at']=\Carbon\Carbon::now();
                  DB::table('user_activity')->insert($activity);
                
            return redirect()->back()->with('success','Your Community added successfully');
        }else
        {
            return view('user.create_community');
        }
    }

    public function communities(Request $request)
    {
        $community=Community::get();
        $url=last(request()->segments());
        $categoryall=\DB::table('category')->take(6)->get();
        $category=\DB::table('category')->where('continent',1)->get();
        $poll=\DB::table('admin_poll')->where('status',1)->first();
        $url=$request->path();
        $catid=\DB::table('category')->where('slug',$url)->first();
        $categorylist=\DB::table('category')
                ->leftjoin('continents','category.continent','continents.id')
                ->where('continent_id',$url)
                ->select('category.*','continents.name as conname')
                ->orderBy('category.title','ASC')
                ->get();
        // $subcat=\DB::table('category')
        //         ->leftjoin('category','category.id','subcategory.cat_id')
        //         ->where('cat_id',$catid->id)
        //         ->select('subcategory.*','category.title','category.slug as catslug')
        //         ->orderBy('subcategory.name')
        //         ->groupBy('subcategory.id')
        //         ->get();
         $poll_option= json_decode($poll->poll_options);
         $extension=explode('.',$poll->media);  
        if(!empty(\Session::get('user')))
        {
            $mycommunity=\DB::table('community')
                     ->leftjoin('community_join','community.id','community_join.community_id')
                      ->where('community_join.user_id',\Session::get('user')->id)
                      ->where('community_join.status',1)
                      ->groupBy('community.id')
                      ->take(6)
                      ->get(); 
        }else
        {
            $mycommunity=\DB::table('community')
                     ->leftjoin('community_join','community.id','community_join.community_id')
                      ->groupBy('community.id')
                      ->take(6)
                      ->get(); 
        }
         $totalvotes=\DB::table('admin_poll_votes')->where('poll_id',$poll->id)->count(); 
        return view('user.asia')->with(['community'=>$community,'mycommunity'=>$mycommunity,'category'=>$categoryall,'poll'=>$poll,'poll_option'=>$poll_option,'extension'=>$extension,'totalvotes'=>$totalvotes,'categoryall'=>$category,'url'=>$url,'categorylist'=>$categorylist]);
    }

    public function all_community()
    {
        $community=Community::orderBy('community.title','ASC')->get();
        if(!empty(\Session::get('user')))
        {
            $mycommunity=\DB::table('community')
                     ->leftjoin('community_join','community.id','community_join.community_id')
                      ->where('community_join.user_id',\Session::get('user')->id)
                      ->where('community_join.status',1)
                      ->groupBy('community.id')
                      ->take(6)
                      ->get(); 
        }else
        {
            $mycommunity=\DB::table('community')
                     ->leftjoin('community_join','community.id','community_join.community_id')
                      ->groupBy('community.id')
                      ->take(6)
                      ->get(); 
        }
        $category=\DB::table('category')->take(6)->get();
        $poll=\DB::table('admin_poll')->where('status',1)->first();
         $poll_option= json_decode($poll->poll_options);
         $extension=explode('.',$poll->media);  
         $totalvotes=\DB::table('admin_poll_votes')->where('poll_id',$poll->id)->count(); 
        return view('user.all_community')->with(['community'=>$community,'mycommunity'=>$mycommunity,'category'=>$category,'poll'=>$poll,'poll_option'=>$poll_option,'extension'=>$extension,'totalvotes'=>$totalvotes]);
    }

    public function join_community(Request $request)
    {
        date_default_timezone_set('UTC');
        
        if(empty(\Session::get('user')))
        {
            return 2;
        }
        $check=\DB::table('community_join')->where('community_id',$request->commid)->where('user_id',\Session::get('user')->id)->first();
        if(empty($check))
        {
            $user=\Session::get('user');
            $data['community_id']=$request->commid;
            $data['user_id']=$user->id;
            $data['status']=$request->status;
            $data['created_at']=\Carbon\Carbon::now();
            $data['updated_at']=\Carbon\Carbon::now();
            $checkcomm=DB::table('community_join')->where('community_id',$request->commid)->where('user_id',$user->id)->first();
            if(!empty($checkcomm))
            {
              DB::table('community_join')->where('community_id',$request->commid)->where('user_id',$user->id)->update(['community_id'=>$request->commid,'user_id'=>$user->id,'status'=>$status,'updated_at'=>\Carbon\Carbon::now()]);
            }else
            {
               $join=\DB::table('community_join')->insertGetId($data);
            }
            

            $activity['post_id']=$request->commid;
            $activity['like_id']='';
            $activity['user_id']=\Session::get('user')->id;
            $communityname=Community::where('id',$request->commid)->first();
            if($request->status==0)
            {
              $status='You left '.$communityname->title.' community';
            }else if($request->status==1)
            {
              $status='You joined '.$communityname->title.' community';
            }
            $activity['status']=$status;
            $activity['type']='community';
            $activity['created_at']=\Carbon\Carbon::now();
            $activity['updated_at']=\Carbon\Carbon::now();
            DB::table('user_activity')->insert($activity);
            $members=\DB::table('community_join')->where('community_id',$request->commid)->where('status',1)->count();
            $res['status']=1;
            $res['total']=$members;
            return $res;
                 
        }else
        {
            $user=\Session::get('user');
            // $data['status']=$request->status;
            // $data['updated_at']=\Carbon\Carbon::now();
            DB::table('community_join')->where('community_id',$request->commid)->where('user_id',$user->id)->update(['status'=>$request->status,'updated_at'=>\Carbon\Carbon::now()]);
            $activity['post_id']=$request->commid;
            $activity['like_id']='';
            $activity['user_id']=\Session::get('user')->id;
            $communityname=Community::where('id',$request->commid)->first();
            if($request->status==0)
            {
              $status='You left '.$communityname->title.' community';
            }else if($request->status==1)
            {
              $status='You joined '.$communityname->title.' community';
            }
            $activity['status']=$status;
            $activity['type']='community';
            $activity['created_at']=\Carbon\Carbon::now();
            $activity['updated_at']=\Carbon\Carbon::now();
            DB::table('user_activity')->insert($activity);
            $members=\DB::table('community_join')->where('community_id',$request->commid)->where('status',1)->count();
            $res['status']=1;
            $res['total']=$members;
            return $res;
        }
        
    }

    public function my_community(Request $request)
    {
        $user=\Session::get('user');
        $mycommunityjoin=\DB::table('community')
                     ->leftjoin('community_join','community.id','community_join.community_id')
                      ->where('community_join.user_id',\Session::get('user')->id)
                      ->where('community_join.status',1)
                      ->groupBy('community.id')
                      ->pluck('community.title')
                      ->toArray(); 
        $community=Community::
                   whereNotIn('title',$mycommunityjoin)
                   ->orderBy('community.title','ASC')
                   ->get();

        if(!empty(\Session::get('user')))
        {
            $mycommunity=\DB::table('community')
                     ->leftjoin('community_join','community.id','community_join.community_id')
                      ->where('community_join.user_id',\Session::get('user')->id)
                      ->where('community_join.status',1)
                      ->groupBy('community.id')
                      ->orderBy('community.title','ASC')
                      ->take(6)
                      ->get(); 
        }else{
            $mycommunity=\DB::table('community')
                     ->leftjoin('community_join','community.id','community_join.community_id')
                      ->groupBy('community.id')
                      ->take(6)
                      ->get(); 
        } 
        $category=\DB::table('category')->take(6)->get();
        $poll=\DB::table('admin_poll')->where('status',1)->first();
         $poll_option= json_decode($poll->poll_options);
         $extension=explode('.',$poll->media);  
         $totalvotes=\DB::table('admin_poll_votes')->where('poll_id',$poll->id)->count(); 
        return view('user.my_community')->with(['mycommunity'=>$mycommunity,'category'=>$category,'poll'=>$poll,'poll_option'=>$poll_option,'extension'=>$extension,'totalvotes'=>$totalvotes,'community'=>$community]);
    }

    public function communityinfo(Request $request,$comm="")
    {

        $community=Community::
                   leftjoin('community_join','community_join.community_id','community.id')
                   ->where('community.title',$comm)
                   ->select('community.*','community_join.community_id','community_join.user_id','community_join.status')
                   ->first();
         $continentname=\DB::table('continents')->where('id',$community->continent)->first();     
        $totalmem=\DB::table('community_join')->where('community_id',$community->community_id)->where('status',1)->count();

        $userposts=DB::table('user_posts')
                   ->where('community_id',$community->community_id)
                   ->orderBy('user_posts.id','DESC')
                   ->get();

        if(!empty(\Session::get('user')))
        {
            $mycommunity=\DB::table('community')
                     ->leftjoin('community_join','community.id','community_join.community_id')
                      ->where('community_join.user_id',\Session::get('user')->id)
                      ->where('community_join.status',1)
                      ->groupBy('community.id')
                      ->take(6)
                      ->get(); 
        }else
        {
            $mycommunity=\DB::table('community')
                     ->leftjoin('community_join','community.id','community_join.community_id')
                      ->groupBy('community.id')
                      ->take(6)
                      ->get(); 
        } 
        $categoryname= \DB::table('category')->where('id',$community->cat_id)->first();
        $subcategoryname= \DB::table('subcategory')->where('id',$community->subcat_id)->first();
        $category=\DB::table('category')->take(6)->get(); 
        $poll=\DB::table('admin_poll')->where('status',1)->first();
         $poll_option= json_decode($poll->poll_options);
         $extension=explode('.',$poll->media);  
         $totalvotes=\DB::table('admin_poll_votes')->where('poll_id',$poll->id)->count();  
        return view('user.community')->with(['community'=>$community,'totalmember'=>$totalmem,'userposts'=>$userposts,'mycommunity'=>$mycommunity,'category'=>$category,'poll'=>$poll,'poll_option'=>$poll_option,'extension'=>$extension,'totalvotes'=>$totalvotes,'categoryname'=>$categoryname,'subcategoryname'=>$subcategoryname,'continentname'=>$continentname]);
    }

    public function subcategorylist(Request $request,$continent='',$cat='')
    {
      $catid=\DB::table('category')->where('slug',$cat)->first();
      $subcategory=SubCategory::leftjoin('category','category.id','subcategory.cat_id')->where('subcategory.continent',$continent)->where('subcategory.cat_id',$catid->id)->select('subcategory.*','category.title','category.slug as catslug')->get();

        if(!empty(\Session::get('user')))
        {
            $mycommunity=\DB::table('community')
                     ->leftjoin('community_join','community.id','community_join.community_id')
                      ->where('community_join.user_id',\Session::get('user')->id)
                      ->where('community_join.status',1)
                      ->groupBy('community.id')
                      ->take(6)
                      ->get(); 
        }else
        {
            $mycommunity=\DB::table('community')
                     ->leftjoin('community_join','community.id','community_join.community_id')
                      ->groupBy('community.id')
                      ->take(6)
                      ->get(); 
        }
        $category=\DB::table('category')->take(6)->get();
        $poll=\DB::table('admin_poll')->where('status',1)->first();
         $poll_option= json_decode($poll->poll_options);
         $extension=explode('.',$poll->media);  
         $totalvotes=\DB::table('admin_poll_votes')->where('poll_id',$poll->id)->count(); 
         return view('user.all_subcategory')->with(['subcategory'=>$subcategory,'mycommunity'=>$mycommunity,'category'=>$category,'poll'=>$poll,'poll_option'=>$poll_option,'extension'=>$extension,'totalvotes'=>$totalvotes,'cat_id'=>$catid->id,'continent'=>$continent]);
    }

    public function subcommunities(Request $request,$con='',$cat='',$subcat='')
    {
      $subcatid=\DB::table('subcategory')->where('slug',$subcat)->first();
      $community=Community::where('cat_id',$subcatid->cat_id)->where('subcat_id',$subcatid->id)->get();

        if(!empty(\Session::get('user')))
        {
            $mycommunity=\DB::table('community')
                     ->leftjoin('community_join','community.id','community_join.community_id')
                      ->where('community_join.user_id',\Session::get('user')->id)
                      ->where('community_join.status',1)
                      ->groupBy('community.id')
                      ->take(6)
                      ->get(); 
        }else
        {
            $mycommunity=\DB::table('community')
                     ->leftjoin('community_join','community.id','community_join.community_id')
                      ->groupBy('community.id')
                      ->take(6)
                      ->get(); 
        }
        $category=\DB::table('category')->take(6)->get();
        $poll=\DB::table('admin_poll')->where('status',1)->first();
         $poll_option= json_decode($poll->poll_options);
         $extension=explode('.',$poll->media);  
         $totalvotes=\DB::table('admin_poll_votes')->where('poll_id',$poll->id)->count(); 
      return view('user.all_community')->with(['community'=>$community,'mycommunity'=>$mycommunity,'category'=>$category,'poll'=>$poll,'poll_option'=>$poll_option,'extension'=>$extension,'totalvotes'=>$totalvotes]);
    }

    public function communitycategory(Request $request,$cat)
    {
        $community=Community::
                   leftjoin('category','category.id','community.cat_id')
                   ->where('category.title',$cat)
                   ->select('community.*')
                   ->orderBy('community.title','ASC')
                   ->get();
        if(!empty(\Session::get('user')))
        {
            $mycommunity=\DB::table('community')
                     ->leftjoin('community_join','community.id','community_join.community_id')
                      ->where('community_join.user_id',\Session::get('user')->id)
                      ->where('community_join.status',1)
                      ->groupBy('community.id')
                      ->take(6)
                      ->get(); 
        }else
        {
            $mycommunity=\DB::table('community')
                     ->leftjoin('community_join','community.id','community_join.community_id')
                      ->groupBy('community.id')
                      ->take(6)
                      ->get(); 
        }
        $category=\DB::table('category')->take(6)->get();
        $poll=\DB::table('admin_poll')->where('status',1)->first();
         $poll_option= json_decode($poll->poll_options);
         $extension=explode('.',$poll->media);  
         $totalvotes=\DB::table('admin_poll_votes')->where('poll_id',$poll->id)->count(); 
        return view('user.all_community')->with(['community'=>$community,'mycommunity'=>$mycommunity,'category'=>$category,'poll'=>$poll,'poll_option'=>$poll_option,'extension'=>$extension,'totalvotes'=>$totalvotes]);
    }

    public function search_community(Request $request)
    {
      
       $community=Community::
                   where('community.title',$request->name)
                   ->select('community.*')
                   ->orderBy('community.title','ASC')
                   ->get();
        if(!empty(\Session::get('user')))
        {
            $mycommunity=\DB::table('community')
                     ->leftjoin('community_join','community.id','community_join.community_id')
                      ->where('community_join.user_id',\Session::get('user')->id)
                      ->where('community_join.status',1)
                      ->groupBy('community.id')
                      ->take(6)
                      ->get(); 
        }else
        {
            $mycommunity=\DB::table('community')
                     ->leftjoin('community_join','community.id','community_join.community_id')
                      ->groupBy('community.id')
                      ->take(6)
                      ->get(); 
        }
        $category=\DB::table('category')->take(6)->get();
        $poll=\DB::table('admin_poll')->where('status',1)->first();
         $poll_option= json_decode($poll->poll_options);
         $extension=explode('.',$poll->media);  
         $totalvotes=\DB::table('admin_poll_votes')->where('poll_id',$poll->id)->count(); 
        return view('user.all_community')->with(['community'=>$community,'mycommunity'=>$mycommunity,'category'=>$category,'poll'=>$poll,'poll_option'=>$poll_option,'extension'=>$extension,'totalvotes'=>$totalvotes]);
    }

    public function communitysearch(Request $request)
    {

        $community=Community::
                   where('community.title',$request->community)
                   ->first();
        if(!empty($community))
        {
          if(!empty(\Session::get('user')->id))
          {
          $join=\DB::table('community_join')->where('community_id',$community->id)->where('user_id',\Session::get('user')->id)->where('status',1)->first(); 
          }else
          {
            $join='';
          }
          $totalmember= \DB::table('community_join')->where('community_id',$community->id)->where('status',1)->count(); 
        }        
        if(!empty($community)>0)
        {
          if(!empty($join))
          {
              $response['join']=1;
          }else
          {
              $response['join']=0;
          }
          if(!empty(\Session::get('user')->id))
          {
              $response['user']=1;
          }else
          {
              $response['user']=0;
          }
          $response['community']=  $community;
          $response['status']=1;
          $response['total']=$totalmember;
        }else{
          $response['status']=0;
        }  
        return $response;         
    }
}
