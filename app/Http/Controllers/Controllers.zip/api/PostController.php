<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Helpers\Helper;
use DB;
use File;
use App\Models\UserPost;
use App\Models\Comment;
use App\Models\PostLikes;
use Intervention\Image\Facades\Image;
use Stevebauman\Location\Facades\Location;

class PostController extends Controller
{
    public function create_post(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
				$json=array();
				$input=$request->all();
				$rules=array(
	            'community_name' => 'required',
	            'title' => 'required',
	           );
			   $messages=array(
			        'community_name.required' => 'Please enter community name.',
			        'title.required' => 'Please enter title.'
			    );
		        $validator=\Validator::make($request->all(),$rules,$messages);
		        
		        $communityname=$input['community_name'];
				$title=$input['title'];
		        
				if($request->hasFile('media'))
	            {
	                $fileextension=$request->file('media')->getClientOriginalExtension();
	                if($fileextension=='jpg' || $fileextension=='jpeg' || $fileextension=='png')
	                {
	                    $originalImage= $request->file('media');
	                    $thumbnailImage = Image::make($originalImage);
	                    $thumbnailPath = public_path().'/post_image/';
	                    if (! File::exists($thumbnailPath))
	                    {
	                        File::makeDirectory($thumbnailPath, 0777, true, true);
	                    }
	                    $rand=rand(1111,9999);
	                    $originalPath = public_path().'/post/';
	                    if (! File::exists($originalPath))
	                    {
	                        File::makeDirectory($originalPath, 0777, true, true);
	                    }
	                    $thumbnailImage->save($originalPath.'post'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension());
	                    $thumbnailImage->resize(100,100);
	                    $thumbnailImage->save($thumbnailPath.'post'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension());
	                    $insertdata['media']='post'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension();
	                }else
	                {
	                	$rand=rand(1111,9999);
	                    $image = $request->file('media');
	                    $name = 'post'.'-'.$rand.'.'.$image->getClientOriginalExtension();
	                    $destinationPath = public_path('/post');
	                    $image->move($destinationPath, $name);
	                    $insertdata['media']=$name;
	                }
	                
	            }
			    if(!empty($request->post))
			    {
			    	$insertdata['post'] = '<p>'.$request->post.'</p>';
			    }

			    $insertdata['community_id'] = $communityname;
			    $insertdata['title'] = $title;
			    $insertdata['type'] = 'post';
			    $insertdata['slug'] = str_slug($title);
			    $insertdata['user_id'] = $user->id;
			    $insertdata['created_at'] = \Carbon\Carbon::now();
			    $insertdata['updated_at'] = \Carbon\Carbon::now();
			    $post=DB::table('user_posts')->insertGetId($insertdata);


			    $activity['post_id']=$post;
                $activity['like_id']='';
                $activity['user_id']=$user->id;
                $activity['type']='post';
                $activity['status']='You created a post';
                $activity['created_at']=\Carbon\Carbon::now();
                $activity['updated_at']=\Carbon\Carbon::now();
                DB::table('user_activity')->insert($activity);
			   
				$Json['status']=true;
    			$Json['community']='Post created successfully';
    			return response()->json(array($Json));
    			die;
			}else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function create_poll(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{

			if($request->isMethod('post'))
			{
				$json=array();
				$input=$request->all();
				$rules=array(
	            'community_name' => 'required',
	            'question' => 'required',
	            'option' => 'required',
	           );
			   $messages=array(
			        'community_name.required' => 'Please enter community name.',
			        'question.required' => 'Please enter question.',
			        'option.required' => 'Please enter option.',
			    );
		        $validator=\Validator::make($request->all(),$rules,$messages);
		        
		        $communityname=$input['community_name'];
				$question=$input['question'];
				$option=implode('-',$input['option']);

			    $insertdata['community_id'] = $communityname;
			    $insertdata['question'] = $question;
			    $insertdata['queoption'] = $option;
			    if(!empty($input['multiple']))
			    {
			    	$insertdata['multiple'] = $input['multiple'];
			    }
			    
			    $insertdata['type'] = 'poll';
			    $insertdata['slug'] = str_slug($question);
			    $insertdata['user_id'] = $user->id;
			    $insertdata['created_at'] = \Carbon\Carbon::now();
			    $insertdata['updated_at'] = \Carbon\Carbon::now();
			    $poll=DB::table('user_posts')->insertGetId($insertdata);

			    $activity['post_id']=$poll;
                $activity['like_id']='';
                $activity['user_id']=$user->id;
                $activity['type']='post';
                $activity['status']='You created a poll';
                $activity['created_at']=\Carbon\Carbon::now();
                $activity['updated_at']=\Carbon\Carbon::now();
                DB::table('user_activity')->insert($activity);
			   
				$Json['status']=true;
    			$Json['community']='Poll created successfully';
    			return response()->json(array($Json));
    			die;
			}else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function likepost(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
    	        $check=PostLikes::where('post_id',$request->postid)->where('user_id',$user->id)->first();
	            if(!empty($check))
	            {
	                date_default_timezone_set('UTC');
	                $postlike=PostLikes::where('post_id',$request->postid)->where('user_id',$user->id)->first();
	                $postlike->like=$request->like;
	                $postlike->updated_at=\Carbon\Carbon::now();
	                $postlike->save(); 
	                $userpost=UserPost::leftjoin('users','users.id','user_posts.user_id')->where('user_posts.id',$request->postid)->select('user_posts.*','users.name as username')->first();
	                $totallike=DB::table('posts_likes')->where('post_id',$request->postid)->where('like',1)->count();
	                 if(!empty($userpost))
	                 {
	                 	if($userpost->user_id==$user->id)
		                 {
		                	$users='your';
		                 }else
		                 {
		                	$users=$userpost->username."'s";
		                 }
	                 }else
	                 {
	                 	$users='this';
	                 }
                     
	                  $activity['post_id']=$request->postid;
	                  $activity['like_id']=$postlike->id;
	                  $activity['user_id']=$user->id;
	                  $activity['type']='post';
	                  $activity['status']='You liked '.$users.' post';
	                  $activity['created_at']=\Carbon\Carbon::now();
	                  $activity['updated_at']=\Carbon\Carbon::now();
	                  DB::table('user_activity')->insert($activity);

	                $Json['status']=true;
    			    $Json['msg']='You liked this post';
    			    $Json['like']=true;
    			    $Json['totallike']=$totallike;
    			    return response()->json(array($Json));
    			    die;
	                
	            }else
	            {
	                date_default_timezone_set('UTC');
	                $postlike=new PostLikes;
	                $postlike->post_id=$request->postid;
	                $postlike->user_id=$user->id;
	                $postlike->like=$request->like;
	                $postlike->created_at=\Carbon\Carbon::now();
	                $postlike->updated_at=\Carbon\Carbon::now();
	                $postlike->save();
	                $userpost=UserPost::leftjoin('users','users.id','user_posts.user_id')->where('user_posts.id',$request->postid)->select('user_posts.*','users.name as fbsql_username(link_identifier)e')->first();
	                $totallike=DB::table('posts_likes')->where('post_id',$request->postid)->where('like',1)->count();
                     if($userpost->user_id==$user->id)
	                 {
	                	$users='your';
	                 }else
	                 {
	                	$users=$userpost->username."'s";
	                 }
	                $activity['post_id']=$request->postid;
	                $activity['like_id']=$postlike->id;
	                $activity['user_id']=$user->id;
	                $activity['type']='post';
	                $activity['status']='You liked '.$users.' post';
	                $activity['created_at']=\Carbon\Carbon::now();
	                $activity['updated_at']=\Carbon\Carbon::now();
	                DB::table('user_activity')->insert($activity);
	                $Json['status']=true;
    			    $Json['msg']='You liked this post';
    			    $Json['like']=true;
    			    $Json['totallike']=$totallike;
    			    return response()->json(array($Json));
    			    die;
	            }
            }else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function unlikepost(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
    	        $check=PostLikes::where('post_id',$request->postid)->where('user_id',$user->id)->first();
	            if(!empty($check))
	            {
	                date_default_timezone_set('UTC');
	                $postlike=PostLikes::where('post_id',$request->postid)->where('user_id',$user->id)->first();
	                $postlike->like=$request->like;
	                $postlike->updated_at=\Carbon\Carbon::now();
	                $postlike->save(); 
	                $userpost=UserPost::leftjoin('users','users.id','user_posts.user_id')->where('user_posts.id',$request->postid)->select('user_posts.*','users.name as username')->first();
	                $totallike=DB::table('posts_likes')->where('post_id',$request->postid)->where('like',1)->count();
	                if($userpost->user_id==$user->id)
	                {
	                	$users='your';
	                }else
	                {
	                	$users=$userpost->username."'s";
	                }
	                  $activity['post_id']=$request->postid;
	                  $activity['like_id']=$postlike->id;
	                  $activity['user_id']=$user->id;
	                  $activity['type']='post';
	                  $activity['status']='You Unliked '.$users.' post';
	                  $activity['created_at']=\Carbon\Carbon::now();
	                  $activity['updated_at']=\Carbon\Carbon::now();
	                  DB::table('user_activity')->insert($activity);

	                $Json['status']=true;
    			    $Json['msg']='You Unliked this post';
    			    $Json['dislike ']=true;
    			    $Json['totallike ']=$totallike;
    			    return response()->json(array($Json));
    			    die;
	                
	            }else
	            {
	                date_default_timezone_set('UTC');
	                $postlike=new PostLikes;
	                $postlike->post_id=$request->postid;
	                $postlike->user_id=$user->id;
	                $postlike->like=$request->like;
	                $postlike->created_at=\Carbon\Carbon::now();
	                $postlike->updated_at=\Carbon\Carbon::now();
	                $postlike->save();
	                $userpost=UserPost::leftjoin('users','users.id','user_posts.user_id')->where('user_posts.id',$request->postid)->select('user_posts.*','users.name as username')->first();
	                $totallike=DB::table('posts_likes')->where('post_id',$request->postid)->where('like',1)->count();
	                if($userpost->user_id==$user->id)
	                {
	                	$user='your';
	                }else
	                {
	                	$user=$userpost->username."'s";
	                }
	                $activity['post_id']=$request->postid;
	                $activity['like_id']=$postlike->id;
	                $activity['user_id']=$user->id;
	                $activity['type']='post';
	                $activity['status']='You Unliked '.$user.' post';
	                $activity['created_at']=\Carbon\Carbon::now();
	                $activity['updated_at']=\Carbon\Carbon::now();
	                DB::table('user_activity')->insert($activity);
	                $Json['status']=true;
    			    $Json['msg']='You Unliked this post';
    			    $Json['dislike ']=true;
    			    $Json['totallike ']=$totallike;
    			    return response()->json(array($Json));
    			    die;
	            }
            }else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function postcomments(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
                date_default_timezone_set('UTC');
                $comment = new Comment;
                if($request->hasFile('media'))
	            {
	                $fileextension=$request->file('media')->getClientOriginalExtension();
	                if($fileextension=='jpg' || $fileextension=='jpeg' || $fileextension=='png')
	                {
	                    $image= $request->file('media');
	                    $thumbnailImage = Image::make($image);
	                    $thumbnailPath = public_path().'/comment_image/';
	                    if (! File::exists($thumbnailPath))
	                    {
	                        File::makeDirectory($thumbnailPath, 0777, true, true);
	                    }
	                    $rand=rand(1111,9999);
	                    $originalPath = public_path().'/comment/';
	                    if (! File::exists($originalPath))
	                    {
	                        File::makeDirectory($originalPath, 0777, true, true);
	                    }
	                    $thumbnailImage->save($originalPath.'comments'.'-'.$rand.'.'.$image->getClientOriginalExtension());
	                    $thumbnailImage->resize(100,100);
	                    $thumbnailImage->save($thumbnailPath.'comments'.'-'.$rand.'.'.$image->getClientOriginalExtension());
	                    $insertdata['media']='comments'.'-'.$rand.'.'.$image->getClientOriginalExtension();
	                    $name='comments'.'-'.$rand.'.'.$image->getClientOriginalExtension();
				        $comment->media=$name;
	                }else
	                {
	                	$rand=rand(1111,9999);
	                    $image = $request->file('media');
	                    $name = 'comments'.'-'.$rand.'.'.$image->getClientOriginalExtension();
	                    $destinationPath = public_path('/comment');
	                    $image->move($destinationPath, $name);
	                    $comment->media=$name;
	                }  
	            }
	            $comment->community_id = $request->community_id;
		        $comment->post_id = $request->post_id;
		        $comment->comment = $request->comment;
		        $comment->title = $request->title;
		        $comment->user()->associate($user->id);
		        $post = UserPost::find($request->get('post_id'));
		        $check=$post->comments()->save($comment);
		        $userpost=UserPost::leftjoin('users','users.id','user_posts.user_id')->where('user_posts.id',$request->post_id)->select('user_posts.*','users.name as username')->first();
	                if($userpost->user_id==$user->id)
	                {
	                	$users='your';
	                }else
	                {
	                	$users=$userpost->username."'s";
	                }
		        $activity['post_id']=$request->post_id;
		        $activity['comment_id']=$check->id;
		        $activity['user_id']=$user->id;
		        $activity['type']='post';
		        $activity['status']='You commented on '.$users.' post';
		        $activity['created_at']=\Carbon\Carbon::now();
		        $activity['updated_at']=\Carbon\Carbon::now();
		        DB::table('user_activity')->insert($activity);

		        $details=DB::table('user_comments')->where('id',$check->id)->first();
		        // $time=$details->created_at->diffForHumans();
		        $time=\Carbon\Carbon::parse($details->created_at)->diffForhumans();
		        if(!empty($user))
		        {
		           $userimg=DB::table('user_detail')->where('user_id',$user->id)->first(); 
		            // $userimage=public_path('/user/images/'.$userimg);
		        }
		        if(!empty($userimg))
		        {
		           $userimage=asset('public/user/images/'.$userimg->image); 
		        }else
		        {
		            $userimage=asset('public/images/user.png');
		        }
		        if(!empty($request->comment))
		        {
		            $comment=strip_tags($request->comment);
		            $title='';
		        }else if(!empty($request->media))
		        {
		            $comment=asset('public/comment/'.$name);
		            $title=$request->title;
		        }
		       if($check)
		       {
		        $Json['status']=true;
			    $Json['comment']=$comment;
		        $Json['community_id']=$request->community_id;
		        $Json['post_id']=$request->post_id;
		        $Json['comment_id']=$check->id;
		        $Json['title']=$title;
		        $Json['status']=1;
		        $Json['time']=$time;
		        $Json['name']=$user->name;
		        $Json['image']=$userimage;
			    return response()->json(array($Json));
		       }
                
            }else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function postreply(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
                date_default_timezone_set('UTC');
                $checkcomm=Comment::where('post_id',$request->post_id)->where('id',$request->comment_id)->whereNull('parent_id')->first();
		        if(!empty($checkcomm))
		        {
		            $maincommid=$checkcomm->id;
		        }else
		        {
		            $mainid=Comment::where('post_id',$request->post_id)->where('id',$request->comment_id)->whereNotNull('parent_id')->first();
		            $maincommid=$mainid->main_comment_id;
		        }
		        $userpost=DB::table('user_posts')->where('id',$request->post_id)->first();
		        if(is_numeric($userpost->community_id))
			     {
			     	$communityid=$userpost->community_id;
			     }else
			     {
			     	$usercommunity=DB::table('community')->where('title',$userpost->community_id)->first();
			     	$communityid=$usercommunity->id;
			     }
                $reply = new Comment();
		        $reply->comment = $request->comment;
		        $reply->community_id = $communityid ?? '';
		        $reply->post_id = $request->post_id;
		        $reply->user()->associate($user->id);
		        $reply->parent_id = $request->comment_id;
		        $reply->main_comment_id = $maincommid;
		        // dd($reply);
		        $post = UserPost::find($request->post_id);
		        // dd($post);
		        $check=$post->comments()->save($reply);
		        $userpost=UserPost::leftjoin('users','users.id','user_posts.user_id')->where('user_posts.id',$request->post_id)->select('user_posts.*','users.name as username')->first();
                if($userpost->user_id==$user->id)
                {
                	$users='your';
                }else
                {
                	$users=$userpost->username."'s";
                }
		        $activity['post_id']=$request->post_id;
		        $activity['comment_id']=$check->id;
		        $activity['user_id']=$user->id;
		        $activity['type']='post';
		        $activity['status']='You replied on '.$users.' post';
		        $activity['created_at']=\Carbon\Carbon::now();
		        $activity['updated_at']=\Carbon\Carbon::now();
		        DB::table('user_activity')->insert($activity);

		        $details=DB::table('user_comments')->where('id',$check->id)->first();
		        // $time=$details->created_at->diffForHumans();
		        $time=\Carbon\Carbon::parse($details->created_at)->diffForhumans();
		        if(!empty($user))
		        {
		           $userimg=DB::table('user_detail')->where('user_id',$user->id)->first(); 
		            // $userimage=public_path('/user/images/'.$userimg);
		        }
		        if(!empty($userimg))
		        {
		           $userimage=asset('public/user/images/'.$userimg->image); 
		        }else
		        {
		            $userimage=asset('public/images/user.png');
		        }
                $comment=strip_tags($request->comment);
                $Json['status']='true';
		        $Json['comment']=$comment;
		        $Json['community_id']=$request->community_id;
		        $Json['post_id']=$request->post_id;
		        $Json['comment_id']=$check->id;
		        $Json['time']=$time;
		        $Json['name']=$user->name;
		        $Json['image']=$userimage;
			    return response()->json(array($Json));
		        
            }else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function commentlike(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
                date_default_timezone_set('UTC');
                $checkcomment=\DB::table('comments_like')->where('comment_id',$request->commentid)->where('user_id',$user->id)->first();
		    	if(empty($checkcomment))
		    	{
		    		$comment['community_id']=$request->communityid;
			    	$comment['post_id']=$request->postid;
			    	$comment['comment_id']=$request->commentid;
			    	$comment['user_id']=$user->id;
			    	$comment['like']=$request->status;
			    	$comment['created_at']=\Carbon\Carbon::now();
			    	$comment['updated_at']=\Carbon\Carbon::now();
			    	\DB::table('comments_like')->insert($comment);
		    	}else
		    	{
		    		$comment['community_id']=$request->communityid;
			    	$comment['post_id']=$request->postid;
			    	$comment['comment_id']=$request->commentid;
			    	// $comment['sub_comm_id']=$request->reply_id;
			    	$comment['user_id']=$user->id;
			    	$comment['like']=$request->status;
			    	$comment['updated_at']=\Carbon\Carbon::now();
			    	\DB::table('comments_like')->where('comment_id',$request->commentid)->where('user_id',$user->id)->update($comment);
		    	}
		    	
		    	$totalcommlike=\DB::table('comments_like')->where('comment_id',$request->commentid)->where('like',1)->count();
		    	$Json['status']=true;
    			$Json['totallike']=$totalcommlike;
    			$Json['msg']='Comment liked successfully';
    			return response()->json(array($Json));
    			die;
			    return response()->json(array($Json));
		        
            }else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function commentdislike(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
                date_default_timezone_set('UTC');
                $checkcomment=\DB::table('comments_like')->where('comment_id',$request->commentid)->where('user_id',$user->id)->first();
		    	if(empty($checkcomment))
		    	{
		    		$comment['community_id']=$request->communityid;
			    	$comment['post_id']=$request->postid;
			    	$comment['comment_id']=$request->commentid;
			    	$comment['user_id']=$user->id;
			    	$comment['like']=$request->status;
			    	$comment['created_at']=\Carbon\Carbon::now();
			    	$comment['updated_at']=\Carbon\Carbon::now();
			    	\DB::table('comments_like')->insert($comment);
		    	}else
		    	{
		    		$comment['community_id']=$request->communityid;
			    	$comment['post_id']=$request->postid;
			    	$comment['comment_id']=$request->commentid;
			    	// $comment['sub_comm_id']=$request->reply_id;
			    	$comment['user_id']=$user->id;
			    	$comment['like']=$request->status;
			    	$comment['updated_at']=\Carbon\Carbon::now();
			    	\DB::table('comments_like')->where('comment_id',$request->commentid)->where('user_id',$user->id)->update($comment);
		    	}
		    	
		    	$totalcommlike=\DB::table('comments_like')->where('comment_id',$request->commentid)->where('like',1)->count();
		    	$Json['status']=true;
    			$Json['totallike']=$totalcommlike;
    			$Json['msg']='Comment disliked successfully';
    			return response()->json(array($Json));
    			die;
			    return response()->json(array($Json));
		        
            }else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    

    public function comment_report(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
                date_default_timezone_set('UTC');
                $checkreport=DB::table('comment_report')->where('comment_id',$request->comment_id)->where('user_id',$user->id)->first();
		    	if(empty($checkreport))
		    	{
		    		$report['community_id']=$request->community_id;
			    	$report['post_id']=$request->post_id;
			    	$report['comment_id']=$request->comment_id;
			    	$report['user_id']=$user->id;
			    	$report['report']=$request->comment_report;
			    	$report['created_at']=\Carbon\Carbon::now();
			    	$report['updated_at']=\Carbon\Carbon::now();
			    	DB::table('comment_report')->insert($report);
		    	}else
		    	{
		    		$report['community_id']=$request->community_id;
			    	$report['post_id']=$request->post_id;
			    	$report['comment_id']=$request->comment_id;
			    	$report['user_id']=$user->id;
			    	$report['report']=$request->comment_report;
			    	$report['updated_at']=\Carbon\Carbon::now();
			    	DB::table('comment_report')->where('comment_id',$request->comment_id)->where('user_id',$user->id)->update($report);
		    	}
		    	$Json['status']=true;
    			$Json['msg']='Thanks for your report! Your reporting helps make our website a better, safer, and more welcoming place for everyone; and it means a lot to us.';
    			return response()->json(array($Json));
    			die;
		        
            }else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function hidepost(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
                date_default_timezone_set('UTC');
                $check=DB::table('post_hide')->where('post_id',$request->postid)->where('user_id',$user->id)->first();
		          if(!empty($check))
		          {
	                  DB::table('post_hide')->where('post_id',$request->postid)->where('user_id',$user->id)->update(['status'=>$request->status]);
	                  if($request->status==1)
	                  {
	                    $status='hide-post';
	                  }else if($request->status==0)
	                  {
	                    $status='show-post';
	                  }
	                  $userpost=UserPost::leftjoin('users','users.id','user_posts.user_id')->where('user_posts.id',$request->postid)->select('user_posts.*','users.name as username')->first();
		               if($userpost->user_id==$user->id)
		                {
		                	$users='your';
		                }else
		                {
		                	$users=$userpost->username."'s";
		                }
	                  $activity['post_id']=$request->postid;
	                  $activity['like_id']='';
	                  $activity['user_id']=$user->id;
	                  $activity['type']='post';
	                  $activity['status']='You hide '.$users.' post';
	                  $activity['created_at']=\Carbon\Carbon::now();
	                  $activity['updated_at']=\Carbon\Carbon::now();
	                  DB::table('user_activity')->insert($activity);
		                
		          }else
		          {
		            $hide['user_id']=$user->id;
		            $hide['post_id']=$request->postid;
		            $hide['status']=$request->status;
		            $hide['created_at']=\Carbon\Carbon::now();
		            $hide['updated_at']=\Carbon\Carbon::now();
		            DB::table('post_hide')->insert($hide);
		                if($request->status==1)
		                  {
		                    $status='hide-post';
		                  }else if($request->status==0)
		                  {
		                    $status='show-post';
		                  }
		                  $userpost=UserPost::leftjoin('users','users.id','user_posts.user_id')->where('user_posts.id',$request->postid)->select('user_posts.*','users.name as username')->first();
		                   if($userpost->user_id==$user->id)
			                {
			                	$users='your';
			                }else
			                {
			                	$users=$userpost->username."'s";
			                }
		                  $activity['post_id']=$request->postid;
		                  $activity['like_id']='';
		                  $activity['user_id']=$user->id;
		                  $activity['type']='post';
		                  $activity['status']='You hide '.$users.' post';
		                  $activity['created_at']=\Carbon\Carbon::now();
		                  $activity['updated_at']=\Carbon\Carbon::now();
		                  DB::table('user_activity')->insert($activity);    
		          }
		    	$Json['status']=true;
    			$Json['msg']='Post hide successfully';
    			return response()->json(array($Json));
    			die;
		        
            }else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function unhidepost(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
                date_default_timezone_set('UTC');
                $check=DB::table('post_hide')->where('post_id',$request->postid)->where('user_id',$user->id)->first();
		          if(!empty($check))
		          {
	                  DB::table('post_hide')->where('post_id',$request->postid)->where('user_id',$user->id)->update(['status'=>$request->status]);
	                  if($request->status==1)
	                  {
	                    $status='hide-post';
	                  }else if($request->status==0)
	                  {
	                    $status='show-post';
	                  }
	                  $userpost=UserPost::leftjoin('users','users.id','user_posts.user_id')->where('user_posts.id',$request->postid)->select('user_posts.*','users.name as username')->first();
		                   if($userpost->user_id==$user->id)
			                {
			                	$users='your';
			                }else
			                {
			                	$users=$userpost->username."'s";
			                }
	                  $activity['post_id']=$request->postid;
	                  $activity['like_id']='';
	                  $activity['user_id']=$user->id;
	                  $activity['type']='post';
	                  $activity['status']='You unhide '.$users.' post';
	                  $activity['created_at']=\Carbon\Carbon::now();
	                  $activity['updated_at']=\Carbon\Carbon::now();
	                  DB::table('user_activity')->insert($activity);
		                
		          }else
		          {
		            $hide['user_id']=$user->id;
		            $hide['post_id']=$request->postid;
		            $hide['status']=$request->status;
		            $hide['created_at']=\Carbon\Carbon::now();
		            $hide['updated_at']=\Carbon\Carbon::now();
		            DB::table('post_hide')->insert($hide);
		                if($request->status==1)
		                  {
		                    $status='hide-post';
		                  }else if($request->status==0)
		                  {
		                    $status='show-post';
		                  }
		                  $userpost=UserPost::leftjoin('users','users.id','user_posts.user_id')->where('user_posts.id',$request->postid)->select('user_posts.*','users.name as username')->first();
		                   if($userpost->user_id==$user->id)
			                {
			                	$users='your';
			                }else
			                {
			                	$users=$userpost->username."'s";
			                }
		                  $activity['post_id']=$request->postid;
		                  $activity['like_id']='';
		                  $activity['user_id']=$user->id;
		                  $activity['type']='post';
		                  $activity['status']='You unhide '.$users.' post';
		                  $activity['created_at']=\Carbon\Carbon::now();
		                  $activity['updated_at']=\Carbon\Carbon::now();
		                  DB::table('user_activity')->insert($activity);    
		          }
		    	$Json['status']=true;
    			$Json['msg']='Post unhide successfully';
    			return response()->json(array($Json));
    			die;
		        
            }else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function reportpost(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
                date_default_timezone_set('UTC');
               $check=DB::table('user_post_reports')->where('user_id',$user->id)->first();
		       if(empty($check))
		       {
		            DB::table('user_post_reports')->insert(['user_id'=>$user->id,'post_id'=>$request->postid,'report'=>$request->report,'created_at'=>\Carbon\Carbon::now(),'updated_at'=>\Carbon\Carbon::now()]);
		            $checkpost=DB::table('user_activity')->where('post_id',$request->postid)->where('user_id',$user->id)->first();
		                if(empty($checkpost))
		                {
		                	$userpost=UserPost::leftjoin('users','users.id','user_posts.user_id')->where('user_posts.id',$request->postid)->select('user_posts.*','users.name as username')->first();
		                   if($userpost->user_id==$user->id)
			                {
			                	$user='your';
			                }else
			                {
			                	$user=$userpost->username."'s";
			                }
		                  $activity['post_id']=$request->postid;
		                  $activity['like_id']='';
		                  $activity['user_id']=$user->id;
		                  $activity['type']='post';
		                  $activity['status']='You reported on '.$user.' post';
		                  $activity['created_at']=\Carbon\Carbon::now();
		                  $activity['updated_at']=\Carbon\Carbon::now();
		                  DB::table('user_activity')->insert($activity);
		                }
		       }else
		       {
		        DB::table('user_post_reports')->where('user_id',$user->id)->update(['report'=>$request->report,'post_id'=>$request->postid,'updated_at'=>\Carbon\Carbon::now()]);
		        $checkpost=DB::table('user_activity')->where('post_id',$request->postid)->where('user_id',$user->id)->first();
		                if(empty($checkpost))
		                {
		                	$userpost=UserPost::leftjoin('users','users.id','user_posts.user_id')->where('user_posts.id',$request->postid)->select('user_posts.*','users.name as username')->first();
		                   if($userpost->user_id==$user->id)
			                {
			                	$user='your';
			                }else
			                {
			                	$user=$userpost->username."'s";
			                }
		                  $activity['post_id']=$request->postid;
		                  $activity['like_id']='';
		                  $activity['user_id']=$user->id;
		                  $activity['type']='post';
		                  $activity['status']='You reported on '.$user.' post';
		                  $activity['created_at']=\Carbon\Carbon::now();
		                  $activity['updated_at']=\Carbon\Carbon::now();
		                  DB::table('user_activity')->insert($activity);
		                }
		       }
		    	$Json['status']=true;
    			$Json['msg']='Thanks for your report! Your reporting helps make our website a better, safer, and more welcoming place for everyone; and it means a lot to us.';
    			return response()->json(array($Json));
    			die;
		        
            }else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }


    public function pollofmonth(Request $request)
    {
    	$poll=DB::table('admin_poll')->where('status',1)->first();
    	$pollcount=DB::table('admin_poll_votes')->where('poll_id',$poll->id)->count();
    	$Json['status']=true;
    	$Json['totalvotes']=$pollcount;
    	
    	$Json['id']=$poll->id;
    	$Json['title']=$poll->question;
    	$options=explode(',', $poll->poll_options);
    	$alloption=[];
    	foreach ($options as $key => $val)
    	{
    		$qoption=trim($val);
    		$newoption=str_replace('["', '', $qoption);
    		$newoption1=str_replace('"', '', $newoption);
    		$newoption2['key']=str_replace(']', '', $newoption1);
    		$alloption[]=$newoption2;
    	}
    	$Json['options']=$alloption;
    	if($poll->multiple==1)
    	{
    		$Json['multiple_choice']=$poll->question;
    	}
    	$Json['created_time']=date('d-m-y h:m:ia',strtotime($poll->time));
    	
		// $Json['poll']=$poll;
		return response()->json(array($Json));
    }

    public function mypost(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
                date_default_timezone_set('UTC');
    	        $userpost=UserPost::leftjoin('community','community.id','user_posts.community_id')->where('user_posts.user_id',$user->id)->select('user_posts.*','community.title as community')->get();
    	        if(count($userpost)>0)
    	        {
    	        	
			            $mypost=UserPost::leftjoin('community','community.id','user_posts.community_id')->where('user_posts.user_id',$user->id)->select('community.title as community','user_posts.id','user_posts.type','user_posts.title','user_posts.slug','user_posts.question','user_posts.queoption','user_posts.post','user_posts.media','user_posts.created_at')->get();
				            foreach ($mypost as $key => $post)
				            {
				            	$totallike=DB::table('posts_likes')->where('post_id',$post->id)->where('like',1)->count();
			                 	$totalcomment=DB::table('user_comments')->where('post_id',$post->id)->count();
			                 	$likepost=DB::table('posts_likes')->where('post_id',$post->id)->where('like',1)->where('user_id',$user->id)->first();
			                 	// $allcommunity->community=$allcommunity->community;
								$post->community=$post->community;
								$post->id=$post->id;
								$post->type=$post->type;
								$post->title=$post->title;
								$post->slug=$post->slug;
								if($post->type=='poll')
								{
									$post->question=$post->question;
								    $options=explode('-',$post->queoption);
								    $alloption=[];
							    	foreach ($options as $key => $val)
							    	{
							    		$qoption=trim($val);
							    		$newoption=str_replace('["', '', $qoption);
							    		$newoption1=str_replace('"', '', $newoption);
							    		$newoption2['key']=str_replace(']', '', $newoption1);
							    		$alloption[]=$newoption2;
							    	}
							        $post->queoption = $alloption;
								}
								    $post->post=strip_tags($post->post);
								    if($post->type=='post')
								    {
								    	$post->media=route('home.dashboard').'/public/post/'.$post->media;	
								    }
							    $post->created_at=$post->created_at;
							    if(!empty($likepost))
							    {
							    	$post->islike=true;
							    }else
							    {
							    	$post->islike=false;
							    }
							    $randnum=\Helper::RandNum('5').$post->id;
							    $community=$post->community;
							    $urllink=url('/').'/'.$community.'/comments/'.$randnum.'/'.$post->slug;

							    $post->copy=$urllink;
							    if(!empty($post->title))
								 {
								 	$title=$post->title;
								 }else
								 {
								 	$title='IF I WERE...MAKING THE WORLD A BETTER PLACE';
								 }
								 
								 if(!empty($post->media))
								 {
								 	$media=route('home.dashboard').'/public/post/'.$post->media;
								 }else
								 {
								 	$media=route('home.dashboard').'/public/images/logo.png';
								 }
								 
								 $img=urlencode($media);

							 	$titleweb=urlencode($title);
							 	
							 
							    $post->facebook="http://www.facebook.com/sharer.php?s=100&p[url]=".$urllink."&p[images][0]=$img&p[title]=$titleweb&p[summary]='If I Were'";
							    $post->twitter="https://twitter.com/share?url=".$urllink."&text=IF I WERE...MAKING THE WORLD A BETTER PLACE check this post";
							    $post->linkedin="https://www.linkedin.com/shareArticle?mini=true&url=".$urllink."&title=$post->slug&summary=IF I WERE...MAKING THE WORLD A BETTER PLACE check this post&source=IF I WERE...MAKING THE WORLD A BETTER PLACE";
					   
							    $post->like=$totallike.' likes';
							    $post->comment=$totalcomment.' comments';
							    $myposts[]=$post;
				            }
			                
			                 	
							    
					    $Json['status']=true;
					    $Json['msg']='Post fetched successfully';
						$Json['post']=$myposts;
	    			    return response()->json(array($Json));
	    			    die;
    	        }else
    	        {
    	        	$Json['status']=true;
    			    $Json['msg']='No Post Found';
    			    return response()->json(array($Json));
    			    die;
    	        }
    	        
    	    }else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function editpost(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
                date_default_timezone_set('UTC');
                if(!empty($request->postid))
                {
                	$userpost=UserPost::where('id',$request->postid)->first();
                	if(!empty($request->title))
                	{
                		$userpost->title=$request->title;
                	}
                	if(!empty($request->title))
                	{
		                $userpost->slug=str_slug($request->title);
		            }
		            if(!empty($request->community_id))
                	{
		               $userpost->community_id=$request->community_id;
		            }
		            if(!empty($request->post))
                	{
		               $userpost->post=$request->post;
		            }
		            if(!empty($request->question))
                	{
		               $userpost->question=$request->question;
		            }
		            if(!empty($request->option))
		            {
		               $userpost->queoption=implode('-',$request->option);
		            }
		            
		            // dd($request->post,$userpost);
		            if($request->hasFile('media'))
		            {
		                $path= public_path('/post/'.$userpost->media);
		                if(\File::exists($path))
		                {
		                  \File::delete($path);
		                }
		                $fileextension=$request->file('media')->getClientOriginalExtension();
		                if($fileextension=='jpg' || $fileextension=='jpeg' || $fileextension=='png')
		                {
		                    $originalImage= $request->file('media');
		                    $thumbnailImage = Image::make($originalImage);
		                    $thumbnailPath = public_path().'/post_image/';
		                    if (! File::exists($thumbnailPath))
		                    {
		                        File::makeDirectory($thumbnailPath, 0777, true, true);
		                    }
		                    $rand=rand(1111,9999);
		                    $originalPath = public_path().'/post/';
		                    if (! File::exists($originalPath))
		                    {
		                        File::makeDirectory($originalPath, 0777, true, true);
		                    }
		                    $thumbnailImage->save($originalPath.'post'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension());
		                    $thumbnailImage->resize(100,100);
		                    $thumbnailImage->save($thumbnailPath.'post'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension());
		                    $userpost->media='post'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension();
		                }else
		                {
		                    $image = $request->file('media');
		                    $name = 'post'.'-'.rand(1111,9999).'.'.$image->getClientOriginalExtension();
		                    $destinationPath = public_path('/post');
		                    $image->move($destinationPath, $name);
		                    $userpost->media=$name;
		                }
		            }
	             
	                 $userpost->updated_at=\Carbon\Carbon::now();
	                 $userpost->save();
	                 $Json['status']=true;
    			     $Json['msg']='Post edited successfully';
    			     return response()->json(array($Json));
    			     die;
                }else
                {
                	 $Json['status']=false;
    			     $Json['msg']='Please enter a data for updating data' ;
    			     return response()->json(array($Json));
    			     die;
                }
                
    	    }else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function deletepost(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
				if(empty($request->postid))
                {
                	$Json['status']=false;
    			    $Json['msg']='Post id is required';
    			    return response()->json(array($Json));
    			    die;
                }

		          \DB::table('user_post_reports')->where('post_id',$request->postid)->delete();
		          \DB::table('user_comments')->where('post_id',$request->postid)->delete();
		          \DB::table('user_activity')->where('post_id',$request->postid)->delete();
		          \DB::table('post_hide')->where('post_id',$request->postid)->delete();
		          \DB::table('posts_likes')->where('post_id',$request->postid)->delete();
                	$userpost=UserPost::where('id',$request->postid)->delete();
                	$Json['status']=true;
	    			$Json['msg']='Post deleted successfully';
	    			return response()->json(array($Json));
	    			die;
    	    }else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function reportcontent(Request $request)
    {
    	$Json['status']=true;
		$report=array('Spam','Hate','Not Interested','Misinformation',"Don't Like It",'Fraud','Bullying or harassment','Voilence');
		$Json['report']=$report;
		return response()->json(array($Json));
		die;
    }

    public function user_posts(Request $request)
    {
			$Json=array();
			if($request->isMethod('post'))
			{
				if($request->header('Authorization')) 
			    {
			    $user=Helper::isAuthorize($request);
			    $ip = $request->ip();
        $currentUserInfo = Location::get($ip);
        if (!empty($currentUserInfo))
        { 
            $country=$currentUserInfo->countryName;
            $state=$currentUserInfo->regionName;
            $city=$currentUserInfo->cityName;

            if(empty($user))
            {
                $homepost=UserPost::
                         leftjoin('users','users.id','user_posts.user_id')
                         ->leftjoin('user_location','users.id','user_location.user_id')
                         ->leftjoin('community','community.id','user_posts.community_id')
                         ->leftjoin('user_detail','user_detail.user_id','user_posts.user_id')
                          ->select('community.title as community','community.id as community_id','users.name as username','users.email as useremail','community.title as community','user_detail.image as userimg','user_posts.id','user_posts.type','user_posts.title','user_posts.slug','user_posts.question','user_posts.queoption','user_posts.post','user_posts.media','user_posts.created_at','user_posts.multiple')
                         ->where('user_location.city',$city)
                         ->orWhere('user_location.state',$state)
                         ->orWhere('user_location.country',$country)
                         ->orderBy('user_posts.id','Desc')
                         ->groupBy('user_posts.id')
                         ->get();
             }else
             {
                $homepost=UserPost::
                          leftjoin('users','users.id','user_posts.user_id')
                         ->leftjoin('user_location','users.id','user_location.user_id')
                         ->leftjoin('community','community.id','user_posts.community_id')
                         ->leftjoin('community_join','community.id','community_join.community_id')
                         ->leftjoin('user_detail','user_detail.user_id','user_posts.user_id')
                          ->select('community.title as community','community.id as community_id','users.name as username','users.email as useremail','community.title as community','user_detail.image as userimg','user_posts.id','user_posts.type','user_posts.title','user_posts.slug','user_posts.question','user_posts.queoption','user_posts.post','user_posts.media','user_posts.created_at','user_posts.multiple')
                         ->where('community_join.user_id',$user->id)
                         ->orWhere('user_location.city',$city)
                         ->orWhere('user_location.state',$state)
                         ->orWhere('user_location.country',$country)
                         ->orderBy('user_posts.id','Desc')
                         ->groupBy('user_posts.id')
                         ->get();
             }
            
        }

        if(!empty($homepost))
        {
            $userposts=$homepost;
        }else
        {
            $userposts=UserPost::
                 leftjoin('users','users.id','user_posts.user_id')
                 ->leftjoin('community','community.id','user_posts.community_id')
                 ->leftjoin('user_detail','user_detail.user_id','user_posts.user_id')
                 ->select('community.title as community','community.id as community_id','users.name as username','users.email as useremail','community.title as community','user_detail.image as userimg','user_posts.id','user_posts.type','user_posts.title','user_posts.slug','user_posts.question','user_posts.queoption','user_posts.post','user_posts.media','user_posts.created_at','user_posts.multiple')
                 ->orderBy('id','Desc')
                 ->groupBy('user_posts.id')
                 ->get();
        }
				
                 foreach ($userposts as $key => $post) 
                 {
                 	$totallike=DB::table('posts_likes')->where('post_id',$post->id)->where('like',1)->count();
                 	$likepost=DB::table('posts_likes')->where('post_id',$post->id)->where('like',1)->where('user_id',$user->id)->first();
                 	$userpostcheck=UserPost::where('user_id',$user->id)->first();
	                 	$totalcomment=DB::table('user_comments')->where('post_id',$post->id)->count();
	                 	// $allcommunity->community=$allcommunity->community;
						$post->community_id=$post->community_id;
						$post->community=$post->community;
						$post->userimg=asset('public/user/images/'.$post->userimg);
						$post->id=$post->id;
						$post->type=$post->type;
						if($post->type=='poll' && $post->multiple==1)
						{
							$post->poll_type='Checkbox';
						}else if($post->type=='poll' && $post->multiple==NULL)
						{
							$post->poll_type='Radio';
						}
						$post->title=$post->title;
						$post->slug=$post->slug;
						
						    if($post->type=='post')
						    {
						    	$post->post=strip_tags($post->post);
						    	$post->media=route('home.dashboard').'/public/post/'.$post->media;	
						    }else
						    {
						    	$post->question=$post->question;
						    	$options=explode('-',$post->queoption);
						    	$alloption=[];
						    	foreach ($options as $key => $val)
						    	{
						    		$qoption=trim($val);
						    		$newoption=str_replace('["', '', $qoption);
						    		$newoption1=str_replace('"', '', $newoption);
						    		$newoption2['key']=str_replace(']', '', $newoption1);
						    		$alloption[]=$newoption2;
						    	}
						        $post->queoption = $alloption;
						    	$post->media=null;
						    }
					    $post->created_at=$post->created_at;
					    if(!empty($likepost))
					    {
					    	$post->islike=true;
					    }else
					    {
					    	$post->islike=false;
					    }
					     if(!empty($userpostcheck))
					    {
					    	$post->user=true;
					    }else
					    {
					    	$post->user=false;
					    }
					    
					    $post->like=$totallike.' likes';
					    $post->comment=$totalcomment.' comments';
					$randnum=\Helper::RandNum('5').$post->id;
				    $community=$post->community;
				    $urllink=url('/').'/'.$community.'/comments/'.$randnum.'/'.$post->slug;

				    $post->copy=$urllink;
				    if(!empty($post->title))
					 {
					 	$title=$post->title;
					 }else
					 {
					 	$title='IF I WERE...MAKING THE WORLD A BETTER PLACE';
					 }
					 
					 if(!empty($post->media))
					 {
					 	$media=route('home.dashboard').'/public/post/'.$post->media;
					 }else
					 {
					 	$media=route('home.dashboard').'/public/images/logo.png';
					 }
					 
					 $img=urlencode($media);

				 	$titleweb=urlencode($title);
				 	
				 
				    $post->facebook="http://www.facebook.com/sharer.php?s=100&p[url]=".$urllink."&p[images][0]=$img&p[title]=$titleweb&p[summary]='If I Were'";
				    $post->twitter="https://twitter.com/share?url=".$urllink."&text=IF I WERE...MAKING THE WORLD A BETTER PLACE check this post";
				    $post->linkedin="https://www.linkedin.com/shareArticle?mini=true&url=".$urllink."&title=$post->slug&summary=IF I WERE...MAKING THE WORLD A BETTER PLACE check this post&source=IF I WERE...MAKING THE WORLD A BETTER PLACE";
					    $posts[]=$post;
                 }
                 }else
                 {
                 	    $ip = $request->ip();
				        $currentUserInfo = Location::get($ip);
				        if (!empty($currentUserInfo))
				        { 
				            $country=$currentUserInfo->countryName;
				            $state=$currentUserInfo->regionName;
				            $city=$currentUserInfo->cityName;

				            $homepost=UserPost::
				                         leftjoin('users','users.id','user_posts.user_id')
				                         ->leftjoin('user_location','users.id','user_location.user_id')
				                         ->leftjoin('community','community.id','user_posts.community_id')
				                         ->leftjoin('user_detail','user_detail.user_id','user_posts.user_id')
				                          ->select('community.title as community','community.id as community_id','users.name as username','users.email as useremail','community.title as community','user_detail.image as userimg','user_posts.id','user_posts.type','user_posts.title','user_posts.slug','user_posts.question','user_posts.queoption','user_posts.post','user_posts.media','user_posts.created_at','user_posts.multiple')
				                         ->where('user_location.city',$city)
				                         ->orWhere('user_location.state',$state)
				                         ->orWhere('user_location.country',$country)
				                         ->orderBy('user_posts.id','Desc')
				                         ->groupBy('user_posts.id')
				                         ->get();
				            
				            
				        }

				        if(!empty($homepost))
				        {
				            $userposts=$homepost;
				        }else
				        {
				            $userposts=UserPost::
				                 leftjoin('users','users.id','user_posts.user_id')
				                 ->leftjoin('community','community.id','user_posts.community_id')
				                 ->leftjoin('user_detail','user_detail.user_id','user_posts.user_id')
				                 ->select('community.title as community','community.id as community_id','users.name as username','users.email as useremail','community.title as community','user_detail.image as userimg','user_posts.id','user_posts.type','user_posts.title','user_posts.slug','user_posts.question','user_posts.queoption','user_posts.post','user_posts.media','user_posts.created_at','user_posts.multiple')
				                 ->orderBy('id','Desc')
				                 ->groupBy('user_posts.id')
				                 ->get();
				        }
	                 foreach ($userposts as $key => $post) 
	                 {
	                 	$totallike=DB::table('posts_likes')->where('post_id',$post->id)->where('like',1)->count();
	                 	
		                 	$totalcomment=DB::table('user_comments')->where('post_id',$post->id)->count();
		                 	// $allcommunity->community=$allcommunity->community;
		                 	$post->community_id=$post->community_id;
							$post->community=$post->community;
							$post->userimg=asset('public/user/images/'.$post->userimg);
							$post->id=$post->id;
							$post->type=$post->type;
							$post->title=$post->title;
							$post->slug=$post->slug;
							
							    if($post->type=='post')
							    {
							    	$post->post=strip_tags($post->post);
							    	$post->media=route('home.dashboard').'/public/post/'.$post->media;	
							    }else
							    {
							    	$post->question=$post->question;
							        $post->queoption = explode('-',$post->queoption);
							    	$post->media=null;
							    }
						    $post->created_at=$post->created_at;
						   
						    $post->islike=false;
						    $post->user=false;
						    
						    $post->like=$totallike.' likes';
						    $post->comment=$totalcomment.' comments';
						    $randnum=\Helper::RandNum('5').$post->id;
						    $community=$post->community;
						    $urllink=url('/').'/'.$community.'/comments/'.$randnum.'/'.$post->slug;

						    $post->copy=$urllink;
						    if(!empty($post->title))
							 {
							 	$title=$post->title;
							 }else
							 {
							 	$title='IF I WERE...MAKING THE WORLD A BETTER PLACE';
							 }
							 
							 if(!empty($post->media))
							 {
							 	$media=route('home.dashboard').'/public/post/'.$post->media;
							 }else
							 {
							 	$media=route('home.dashboard').'/public/images/logo.png';
							 }
							 
							 $img=urlencode($media);

						 	$titleweb=urlencode($title);
						 	
						 
						    $post->facebook="http://www.facebook.com/sharer.php?s=100&p[url]=".$urllink."&p[images][0]=$img&p[title]=$titleweb&p[summary]='If I Were'";
						    $post->twitter="https://twitter.com/share?url=".$urllink."&text=IF I WERE...MAKING THE WORLD A BETTER PLACE check this post";
						    $post->linkedin="https://www.linkedin.com/shareArticle?mini=true&url=".$urllink."&title=$post->slug&summary=IF I WERE...MAKING THE WORLD A BETTER PLACE check this post&source=IF I WERE...MAKING THE WORLD A BETTER PLACE";
							    $posts[]=$post;
	                 }
                 }
                
                $Json['posts']=$posts;
                $Json['status']=true;
                return response()->json(array($Json));
				die;	
			}else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
	    
    }

    public function allcomments(Request $request)
    {
    	if($request->isMethod('post'))
		{
			if(!empty($request->post_id))
			{
				$user='';
				if($request->header('Authorization')) 
			    {
			         $user=Helper::isAuthorize($request);
			    }
				$totalcomment=DB::table('user_comments')->where('user_comments.post_id',$request->post_id)->count();
				
				$comment=DB::table('user_comments')
	                 ->leftjoin('users','users.id','user_comments.user_id')
	                 ->leftjoin('user_detail','user_detail.user_id','user_comments.user_id')
	                 ->select('users.name as username','users.email as useremail','user_detail.image as userimg','user_comments.id','user_comments.parent_id','user_comments.comment','user_comments.created_at','user_comments.media')
	                 ->where('user_comments.post_id',$request->post_id)
	                 ->whereNull('user_comments.parent_id')
	                 ->orderBy('user_comments.id','Desc')
	                 ->groupBy('user_comments.id')
	                 ->get();
	                 if(count($comment)>0)
	                 {
	                 	$allcomment=array();
	                 	
	                 foreach ($comment as $key => $comm)
	                 {
	                 	$totallikes=DB::table('comments_like')->where('comments_like.comment_id',$comm->id)->count();
	                 	if(!empty($comm->userimg))
	                 	{
	                 		$allcomm['userimg']=asset('public/user/images/'.$comm->userimg);
	                 	}else
	                 	{
	                 		$allcomm['userimg']=asset('public/images/user.png');
	                 	}
	                 	
		                $allcomm['comment_id']=$comm->id;
		                $allcomm['username']=$comm->username;
		                $allcomm['comment']=strip_tags($comm->comment);
		                $allcomm['totallike']=$totallikes ?? '';
		                if(empty($user))
		                {
		                	$allcomm['islike']=false;
		                }else
		                {
		                	$checklike=DB::table('comments_like')->where('comment_id',$comm->id)->where('user_id',$user->id)->first();
		                	if(empty($checklike))
		                	{
		                		$allcomm['islike']=false;
		                	}else
		                	{
		                		$allcomm['islike']=true;
		                	}
		                }
		                if(!empty($comm->media))
		                {
		                	$allcomm['media']=asset('public/comment/'.$comm->media);
		                }
		                
		                $time=\Carbon\Carbon::parse($comm->created_at)->diffForhumans();
		                $allcomm['time']=$time;
		                $commentreply=DB::table('user_comments')
					                 ->leftjoin('users','users.id','user_comments.user_id')
					                 ->leftjoin('user_detail','user_detail.user_id','user_comments.user_id')
					                 ->select('users.name as username','users.email as useremail','user_detail.image as userimg','user_comments.id','user_comments.parent_id','user_comments.comment','user_comments.created_at','user_comments.parent_id')
					                 ->where('user_comments.post_id',$request->post_id)
					                 ->where('user_comments.main_comment_id',$comm->id)
					                 ->whereNotNull('user_comments.parent_id')
					                 ->orderBy('user_comments.id','Desc')
					                 ->groupBy('user_comments.id')
					                 ->get();
					     $allcomm['reply']=array();            
					     foreach ($commentreply as $key => $reply)
					      {
					      	$totalcommlikes=DB::table('comments_like')->where('comments_like.comment_id',$reply->id)->count();
					      	  if(!empty($reply->userimg))
			                 	{
			                 		$commreply['userimg']=asset('public/user/images/'.$reply->userimg);
			                 	}else
			                 	{
			                 		$commreply['userimg']=asset('public/images/user.png');
			                 	}
			                 	
				                $commreply['reply_id']=$reply->id;
				                $commreply['parent_id']=$reply->parent_id;
				                $commreply['username']=$reply->username;
				                $commreply['comment']=strip_tags($reply->comment);
				                $time=\Carbon\Carbon::parse($reply->created_at)->diffForhumans();
				                $commreply['time']=$time;
				                $commreply['totallike']=$totalcommlikes ?? '';
				                if(empty($user))
					                {
					                	$commreply['islike']=false;
					                }else
					                {
					                	$checklikecom=DB::table('comments_like')->where('comment_id',$reply->id)->where('user_id',$user->id)->first();
					                	if(empty($checklikecom))
					                	{
					                		$commreply['islike']=false;
					                	}else
					                	{
					                		$commreply['islike']=true;
					                	}
					                }
				                $allcomm['reply'][]=$commreply;

					      }  

					      // $comm=array('reply'=>$allreply);          
		                $allcomment[]=$allcomm;
	                 }
	                 	if(!empty($totalcomment))
	                 	{
	                 		$commenttotal=$totalcomment;
	                 	}else
	                 	{
	                 		$commenttotal=0;
	                 	}
	                 	$Json['status']=true;
	                 	$Json['msg']='All comment data fetched successfully';
	                 	$Json['totalcomment']=$commenttotal;
	                    $Json['comment']=$allcomment;
	                    
			            return response()->json(array($Json));
			            }else
			            {
			            	$Json['status']=false;
							$Json['msg']='No comment found for this post';
							return response()->json(array($Json));
			            }	 
	             }else
	             {
	             	$Json['status']=false;
					$Json['msg']='Post id is required';
					return response()->json(array($Json));
	             }
			         
	             
		}else
		{
	  		$Json['status']=false;
			$Json['msg']='Unauthorized Request';
			return response()->json(array($Json));
			die;
	    }

    }
    public function community_post(Request $request)
    {
    	if($request->isMethod('post'))
		{
    	    $userpost=UserPost::
                 leftjoin('users','users.id','user_posts.user_id')
                 ->leftjoin('community','community.id','user_posts.community_id')
                 ->leftjoin('user_detail','user_detail.user_id','user_posts.user_id')
                 ->select('community.title as community','users.name as username','users.email as useremail','community.title as community','user_detail.image as userimg','user_posts.id','user_posts.type','user_posts.title','user_posts.slug','user_posts.question','user_posts.queoption','user_posts.post','user_posts.media','user_posts.created_at')
                 ->where('user_posts.community_id',$request->communityid)
                 ->orderBy('id','Desc')
                 ->groupBy('user_posts.id')
                 ->get()
                 ->map(function($post)
	                 {
	                 	$totallike=DB::table('posts_likes')->where('post_id',$post->id)->where('like',1)->count();
	                 	$totalcomment=DB::table('user_comments')->where('post_id',$post->id)->count();
	                 	// $allcommunity->community=$allcommunity->community;
						$post->community=$post->community;
						$post->userimg=asset('public/user/images/'.$post->userimg);
						$post->id=$post->id;
						$post->type=$post->type;
						$post->title=$post->title;
						$post->slug=$post->slug;
						
						    if($post->type=='post')
						    {
						    	$post->post=strip_tags($post->post);
						    	$post->media=route('home.dashboard').'/public/post/'.$post->media;	
						    }else
						    {
						    	$post->question=$post->question;
						        $post->queoption = explode('-',$post->queoption);
						    	$post->media=null;
						    }
					    $post->created_at=$post->created_at;
					    $post->like=$totallike.' likes';
					    $post->comment=$totalcomment.' comments';
					    return $post;
					  });
	        $Json['status']=true;
			$Json['posts']=$userpost;
			return response()->json(array($Json));         
        }else
		{
	  		$Json['status']=false;
			$Json['msg']='Unauthorized Request';
			return response()->json(array($Json));
			die;
	    }
    }

	    public function pollsubmit(Request $request)
	    {
	    	$user = Helper::isAuthorize($request);
			$Json=array();
			if(!empty($user) && $user->user_status!='0')
			{
		    	if($request->isMethod('post'))
				{
					if(!empty($request->type))
					{
						if(!empty($request->votes))
						{
							if(!empty($request->poll_id))
							{
								foreach ($request->votes as $key => $value)
								{
									$datain['user_id']=$user->id;
									$datain['poll_id']=$request->poll_id;
									$datain['type']=$request->type;
									$datain['votes']=$value;
									$datain['created_at']=\Carbon\Carbon::now();
									$datain['updated_at']=\Carbon\Carbon::now();
									DB::table('admin_poll_votes')->insert($datain);
								}
								
								$Json['status']=true;
								$Json['msg']='Poll submit successfully';
								return response()->json(array($Json));
								die;
							}else
							{
								$Json['status']=false;
								$Json['msg']='Poll id is required';
								return response()->json(array($Json));
								die;
							}
						}else
						{
							$Json['status']=false;
							$Json['msg']='Please select an option';
							return response()->json(array($Json));
							die;
						}
					}else
					{
						$Json['status']=false;
						$Json['msg']='Poll type is required';
						return response()->json(array($Json));
						die;
					}
				}else
				{
			  		$Json['status']=false;
					$Json['msg']='Unauthorized Request';
					return response()->json(array($Json));
					die;
			    }
		    }else
			{
	        	$Json['status']=false;
				$Json['msg']='Sorry,You can not access this page';
				return response()->json(array($Json));
			    die;
			}
	    }

	    public function userpollsubmit(Request $request)
	    {
	    	$user = Helper::isAuthorize($request);
			$Json=array();
			if(!empty($user) && $user->user_status!='0')
			{
		    	if($request->isMethod('post'))
				{
					if(!empty($request->community_id))
					{
					if(!empty($request->votes))
					{
						if(!empty($request->poll_id))
						{
							if(!empty($request->type))
							{
								$checksubmission='';
								foreach ($request->votes as $key => $value)
								{
									$datain['votes']=$value;
					                $datain['user_id']=$user->id;
					                $datain['community_id']=$request->community_id;
					                $datain['post_id']=$request->poll_id;
					                $datain['type']=$request->type;
					                $datain['created_at']=\Carbon\Carbon::now();
					                $datain['updated_at']=\Carbon\Carbon::now();

					                $checksubmission=DB::table('poll_votes')->insert($datain);
								}

								$check=DB::table('poll_votes')->where('user_id',$user->id)->where('post_id',$request->poll_id)->where('community_id',$request->community_id)->first();
							       if(empty($check))
							       {
							             if($request->type=='radio')
							              {
							              	foreach ($request->votes as $key => $value) 
							            	{
								                $datain['votes']=$value;
								                $datain['user_id']=$user->id;
								                $datain['community_id']=$request->community_id;
								                $datain['post_id']=$request->poll_id;
								                $datain['type']=$request->type;
								                $datain['created_at']=\Carbon\Carbon::now();
								                $datain['updated_at']=\Carbon\Carbon::now();
								                DB::table('poll_votes')->insert($datain);
							                }
							              }
							        }else
							       {
							        if($request->type=='radio')
							          {
							            $votes=$request->votes;
							            DB::table('poll_votes')->where('user_id',$user->id)->where('post_id',$request->poll_id)->where('community_id',$request->community_id)->update(['votes'=>$votes,'updated_at'=>\Carbon\Carbon::now()]);
							        }
							       }
							       if($request->type=='checkbox')
							       {
							            DB::table('poll_votes')->where('user_id',$user->id)->where('post_id',$request->poll_id)->where('community_id',$request->community_id)->where('type','checkbox')->delete();
							            foreach ($request->votes as $key => $value) 
							            {
							                  $datain['votes']=$value;
							                  $datain['user_id']=$user->id;
							                  $datain['community_id']=$request->community_id;
							                  $datain['post_id']=$request->poll_id;
							                  $datain['type']=$request->type;
							                  $datain['created_at']=\Carbon\Carbon::now();
							                  $datain['updated_at']=\Carbon\Carbon::now();
							                  DB::table('poll_votes')->insert($datain);
							            }
							        }
							        
							$totalvotes=DB::table('poll_votes')->where('post_id',$request->poll_id)->where('community_id',$request->community_id)->select('post_id', DB::raw('count(*) as total'))->groupBy('user_id')->get();
							$votes=count($totalvotes);
							     
							$Json['status']=true;
							$Json['totalvotes']=$votes;
							$Json['msg']='Poll submit successfully';
							return response()->json(array($Json));
							die;
						}else
						{
							$Json['status']=false;
							$Json['msg']='Poll Type is required';
							return response()->json(array($Json));
							die;
						}
						}else
						{
							$Json['status']=false;
							$Json['msg']='Poll id is required';
							return response()->json(array($Json));
							die;
						}
					}else
					{
						$Json['status']=false;
						$Json['msg']='Please select an option';
						return response()->json(array($Json));
						die;
					}
					}else
					{
						$Json['status']=false;
						$Json['msg']='Community id is required';
						return response()->json(array($Json));
						die;
					}
					
				}else
				{
			  		$Json['status']=false;
					$Json['msg']='Unauthorized Request';
					return response()->json(array($Json));
					die;
			    }
		    }else
			{
	        	$Json['status']=false;
				$Json['msg']='Sorry,You can not access this page';
				return response()->json(array($Json));
			    die;
			}
	    }

	    public function editpoll(Request $request)
	    {
	    	$user = Helper::isAuthorize($request);
			$Json=array();
			if(!empty($user) && $user->user_status!='0')
			{
		    	if($request->isMethod('post'))
				{
				    if(!empty($request->poll_id))
				    {
				    	$userid=$user->id;
			            $userpost=UserPost::where('id',$request->poll_id)->first();
			            $userpost->question=$request->question;
			            $userpost->slug=str_slug($request->question);
			            $userpost->queoption=implode('-', $request->option);
			            $userpost->updated_at=\Carbon\Carbon::now();
			            $userpost->save();

		                $Json['status']=false;
						$Json['msg']='Poll edited successfully';
						return response()->json(array($Json));
						die;
				    }else
				    {
				    	$Json['status']=false;
						$Json['msg']='Poll id is required';
						return response()->json(array($Json));
						die;
				    }
				    
		            
	      		}else
				{
			  		$Json['status']=false;
					$Json['msg']='Unauthorized Request';
					return response()->json(array($Json));
					die;
			    }
		    }else
			{
	        	$Json['status']=false;
				$Json['msg']='Sorry,You can not access this page';
				return response()->json(array($Json));
			    die;
			}
	    }

	    
   }
