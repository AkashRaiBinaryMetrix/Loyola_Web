<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Community;
use App\Models\UserPost;
use App\Models\User;
use App\Models\Faq;
use App\Helpers\Helper;
use DB;
use File;
use Intervention\Image\Facades\Image;

class CommunityController extends Controller
{
    public function join_community(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
				$json=array();
			    $input=$request->all();
			    $community=$input['community'];
			    $status=$input['status'];
			    $checkcommunity=DB::table('community_join')->where('community_id',$community)->where('user_id',$user->id)->where('status',1)->first();
			    if(!empty($checkcommunity))
			    {
			    	$Json['status']=false;
	    			$Json['msg']='Community already Joined!';
	    			$Json['joined']=true;
	    			return response()->json(array($Json));
	    			die;
			    }
			    $checkcomm=DB::table('community_join')->where('community_id',$community)->where('user_id',$user->id)->first();
			    if(!empty($checkcomm))
			    {
			    	DB::table('community_join')->where('community_id',$community)->where('user_id',$user->id)->update(['community_id'=>$community,'user_id'=>$user->id,'status'=>$status,'updated_at'=>\Carbon\Carbon::now()]);
			    }else
			    {
			    	 DB::table('community_join')->insert(['community_id'=>$community,'user_id'=>$user->id,'status'=>$status,'created_at'=>\Carbon\Carbon::now(),'updated_at'=>\Carbon\Carbon::now()]);
			    }
			    $communityname=Community::where('id',$community)->first();
			   
			    $activity['post_id']=$community;
	            $activity['like_id']='';
	            $activity['type']='community';
	            $activity['user_id']=$user->id;
	            $status='You joined '.$communityname->title.' community';
	            $activity['status']=$status;
	            $activity['created_at']=\Carbon\Carbon::now();
	            $activity['updated_at']=\Carbon\Carbon::now();

                DB::table('user_activity')->insert($activity);
				$Json['status']=true;
    			$Json['msg']='Community Joined Successfully!';
    			$Json['joined']=true;
    			return response()->json(array($Json));
    			die;
			}else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function allcommunity(Request $request)
    {
    	$community=Community::orderBy('id','DESC')->get();
    	if(count($community)>0)
    	{
    		$comm = Community::select('id','image','cover_image','title','description','created_at')->get()->map(function($allcommunity){
    			$allcommunity->id=$allcommunity->id;
    			$allcommunity->title=$allcommunity->title;
    			$allcommunity->description=strip_tags($allcommunity->description);
    			$allcommunity->created_at=$allcommunity->created_at;
			    $allcommunity->image = route('home.dashboard').'/public/community/'.$allcommunity->image;
			    $allcommunity->cover_image = route('home.dashboard').'/public/community/'.$allcommunity->cover_image;
			    return $allcommunity;
			});
			
    		   $Json['community']=$comm;
    		   $Json['status']=true;
    	}else
    	{
    		$Json['status']=false;
    		$Json['msg']='No data found';
    	}
    	return response()->json(array($Json));
        die;	
    }

    public function leave_community(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
				$json=array();
			    $input=$request->all();
			    $community=$input['community'];
			    $status=$input['status'];
			    $checkcommunity=DB::table('community_join')->where('community_id',$community)->where('user_id',$user->id)->where('status',0)->first();
			    if(!empty($checkcommunity))
			    {
			    	$Json['status']=false;
	    			$Json['msg']='Community already left!';
	    			$Json['joined']=true;
	    			return response()->json(array($Json));
	    			die;
			    }

			    $checkcomm=DB::table('community_join')->where('community_id',$community)->where('user_id',$user->id)->first();
			    if(!empty($checkcomm))
			    {
			    	DB::table('community_join')->where('community_id',$community)->where('user_id',$user->id)->update(['community_id'=>$community,'user_id'=>$user->id,'status'=>$status,'updated_at'=>\Carbon\Carbon::now()]);
			    }else
			    {
			    	 DB::table('community_join')->insert(['community_id'=>$community,'user_id'=>$user->id,'status'=>$status,'created_at'=>\Carbon\Carbon::now(),'updated_at'=>\Carbon\Carbon::now()]);
			    }
			    $communityname=Community::where('id',$community)->first();
			   
			    $activity['post_id']=$community;
	            $activity['like_id']='';
	            $activity['type']='community';
	            $activity['user_id']=$user->id;
	            $status='You left '.$communityname->title.' community';
	            $activity['status']=$status;
	            $activity['created_at']=\Carbon\Carbon::now();
	            $activity['updated_at']=\Carbon\Carbon::now();
	            DB::table('user_activity')->insert($activity);
				$Json['status']=true;
    			$Json['msg']='Community Left Successfully!';
    			$Json['joined']=false;
    			return response()->json(array($Json));
    			die;
			}else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function mycommunity(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
				$json=array();
			    $community=Community::
			               leftjoin('community_join','community_join.community_id','community.id')
			               ->where('community_join.user_id',$user->id)
			               ->where('community_join.status',1)
			               ->select('community.*')
			               ->groupBy('community.id')
			               ->get();
			    if(count($community)>0)
		    	{
		    		
		    		$comm = Community::
			               leftjoin('community_join','community_join.community_id','community.id')
			               ->where('community_join.user_id',$user->id)
			               ->where('community_join.status',1)
			               ->select('community.id','community.image','community.cover_image','community.title','community.description','community.created_at')->get()->map(function($allcommunity){
		    			$allcommunity->id=$allcommunity->id;
		    			$allcommunity->title=$allcommunity->title;
		    			$allcommunity->description=strip_tags($allcommunity->description);
		    			$allcommunity->created_at=$allcommunity->created_at;
					    $allcommunity->image = route('home.dashboard').'/public/community/'.$allcommunity->image;
					    $allcommunity->cover_image = route('home.dashboard').'/public/community/'.$allcommunity->cover_image;
					    $allcommunity->join=true;
					    return $allcommunity;
					   });
    		          $Json['mycommunity']=$comm;
    		          $Json['status']=true;
		    	}else
		    	{
		    		$Json['status']=false;
		    		$Json['msg']='No data found';
		    	}
		    	return response()->json(array($Json));
		        die;
			   
			}else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function request_community(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
				$json=array();
				$input=$request->all();
				$rules=array(
	            'community_name' => 'required',
	            'description' => 'required',
	            'image' => 'required',
	            'cover_image' => 'required'
	           );
			   $messages=array(
			        'community_name.required' => 'Please enter community name.',
			        'description.required' => 'Please enter description.',
			        'image.required' => 'Please upload profile image.',
			        'cover_image.required' => 'Please upload cover image.'
			    );
		        $validator=\Validator::make($request->all(),$rules,$messages);
		        if($validator->fails())
		        {
		            $Json['status']=false;
			        $Json['community_msg'] = 'Community name is required'; 
			        $Json['description_msg'] = 'Description is required'; 
			        $Json['profile_image_msg'] = 'Profile image is required'; 
			        $Json['cover_image_msg'] = 'Cover image is required'; 
			        return response()->json(array($Json));
			        die;
		        }
		        $communityname=$input['community_name'];
				$description=$input['description'];
		        $checkcomm=Community::where('title',$communityname)->first();
		        if(!empty($checkcomm))
		        {
		        	$Json['status']=false;
		    		$Json['msg']='This community name already exist!';
		    		return response()->json(array($Json));
		        }
				
				if ($request->file('image'))
				{
		            $file = $input['image'];
		            $max=2048;
		            $filehgh =$_FILES['image']['size'];
		            $fileSize = round($filehgh / 1024,4);
		            if($fileSize!=0)
		            {
		            	$originalImage= $request->file('image');
		                $thumbnailImage = Image::make($originalImage);
		                $thumbnailPath = public_path().'/community_image/';
		                if (! File::exists($thumbnailPath))
		                {
		                    File::makeDirectory($thumbnailPath, 0777, true, true);
		                }
		                $rand=rand(1111,9999);
		                $originalPath = public_path().'/community/';
		                if (! File::exists($originalPath))
		                {
		                    File::makeDirectory($originalPath, 0777, true, true);
		                }
		                $thumbnailImage->save($originalPath.'community'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension());
		                $thumbnailImage->resize(100,100);
		                $thumbnailImage->save($thumbnailPath.'community'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension());
		                $insertdata['image']='community'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension();
			        }else
			        {
			            $Json['status']=false;
		    			$Json['msg']='Sorry you can not upload a file more than 2mb!';
		    			return response()->json(array($Json));
			        }
			    }
			    if ($request->file('cover_image'))
				{
		            $file = $input['cover_image'];
		            $max=2048;
		            $filehgh =$_FILES['cover_image']['size'];
		            $fileSize = round($filehgh / 1024,4);
		            if($fileSize!=0)
		            {
		            	$originalImage= $request->file('cover_image');
		                $thumbnailImage = Image::make($originalImage);
		                $thumbnailPath = public_path().'/community_image/';
		                if (! File::exists($thumbnailPath))
		                {
		                    File::makeDirectory($thumbnailPath, 0777, true, true);
		                }
		                $rand=rand(1111,9999);
		                $originalPath = public_path().'/community/';
		                if (! File::exists($originalPath))
		                {
		                    File::makeDirectory($originalPath, 0777, true, true);
		                }
		                $thumbnailImage->save($originalPath.'community'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension());
		                $thumbnailImage->resize(800,350);
		                $thumbnailImage->save($thumbnailPath.'community'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension());
		                $insertdata['cover_image']='community'.'-'.$rand.'.'.$originalImage->getClientOriginalExtension();
			        }else
			        {
			            $Json['status']=false;
		    			$Json['msg']='Sorry you can not upload a file more than 2mb!';
		    			return response()->json(array($Json));
			        }
			    }
			    $insertdata['name'] = $communityname;
			    $insertdata['description'] = $description;
			    $insertdata['user_id'] = $user->id;
			    $insertdata['created_at'] = \Carbon\Carbon::now();
			    $insertdata['updated_at'] = \Carbon\Carbon::now();
			    $commreq=DB::table('user_community')->insertGetId($insertdata);
			    
			   	  $activity['post_id']=$commreq;
                  $activity['like_id']='';
                  $activity['user_id']=$user->id;
                  $activity['status']='You requested to approve a community';
                  $activity['created_at']=\Carbon\Carbon::now();
                  $activity['updated_at']=\Carbon\Carbon::now();
                  DB::table('user_activity')->insert($activity);
				$Json['status']=true;
    			$Json['community']='Your Community added successfully it will show after admin approval';
    			return response()->json(array($Json));
    			die;
			}else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function community_info(Request $request)
    {
    	
		$Json=array();
		if($request->isMethod('post'))
		{

		   if($request->header('Authorization'))
		   {

		   	$auth_key = $request->header('Authorization');
            if(isset($auth_key) && $auth_key != "") {
                $dataa = explode(" ",$auth_key);
                if(isset($dataa[1])){
                    $main_key = $dataa[1];
                }else{
                    $main_key = $auth_key;
                }
            }
                $user = User::where('auth_key', $main_key)->first(); 
		   	if($user->user_status=='0')
		   	{
		   		$Json['status']=false;
				$Json['msg']='Your account is not active Please contact to your administrator';
				return response()->json(array($Json));
			    die;
		   	}
	    	$input=$request->all();
	    	$comm=$input['community'];
	    	$rules=array(
		            'community' => 'required'
		           );
				   $messages=array(
				        'community.required' => 'Please enter community name.'
				    );
			        $validator=\Validator::make($request->all(),$rules,$messages);
			        if($validator->fails())
			        {
			            $Json['status']=false;
				        $Json['msg'] = 'Community name is required'; 
				        return response()->json(array($Json));
				        die;
			        }
	    	$community=Community::
	                   leftjoin('community_join','community_join.community_id','community.id')
	                   ->where('community.id',$comm)
	                   ->select('community.*','community_join.community_id','community_join.user_id','community_join.status')
	                   ->first();
	        $commjoin=DB::table('community_join')->where('community_id',$comm)->count();
	        if(!empty($community))
	        {
	        	$Json['status']=true;
	        	$Json['id']=$community->id;
	        	$Json['title']=$community->title;
	    		$Json['description']=strip_tags($community->description);
	    		$Json['image']=route('home.dashboard').'/public/community/'.$community->image;
	    		$Json['cover_image']=route('home.dashboard').'/public/community/'.$community->cover_image;
	    		$Json['created_at']=$community->created_at;
	    		if($user->id==$community->user_id && $community->status==1)
	    		{
	    			$Json['joined']=true;
	    		}else
	    		{
	    			$Json['joined']=false;
	    		}
			    $Json['total_member']=$commjoin;
				return response()->json(array($Json));
			    die;
	        }else
	        {
	        	$Json['status']=false;
				$Json['msg']='No community found with this name';
				return response()->json(array($Json));
			    die;
	        } 
	    }else
	    {
	    	$input=$request->all();
	    	$comm=$input['community'];
	    	$rules=array(
		            'community' => 'required'
		           );
				   $messages=array(
				        'community.required' => 'Please enter community name.'
				    );
			        $validator=\Validator::make($request->all(),$rules,$messages);
			        if($validator->fails())
			        {
			            $Json['status']=false;
				        $Json['msg'] = 'Community name is required'; 
				        return response()->json(array($Json));
				        die;
			        }
	    	$community=Community::
	                   leftjoin('community_join','community_join.community_id','community.id')
	                   ->where('community.id',$comm)
	                   ->select('community.*','community_join.community_id','community_join.user_id','community_join.status')
	                   ->first();
	        $commjoin=DB::table('community_join')->where('community_id',$comm)->count();
	        if(!empty($community))
	        {
	        	$Json['status']=true;
	        	$Json['id']=$community->id;
	        	$Json['title']=$community->title;
	    		$Json['description']=strip_tags($community->description);
	    		$Json['image']=route('home.dashboard').'/public/community/'.$community->image;
	    		$Json['cover_image']=route('home.dashboard').'/public/community/'.$community->cover_image;
	    		$Json['created_at']=$community->created_at;
	    		$Json['total_member']=$commjoin;
				return response()->json(array($Json));
			    die;
	        }else
	        {
	        	$Json['status']=false;
				$Json['msg']='No community found with this name';
				return response()->json(array($Json));
			    die;
	        }
	    }  
	    }else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }            
    }

    public function allcategory(Request $request)
    {
    	$Json['status']=true;
		$Json['msg']='All category fetched successfully';
    	$allcategory = DB::table('category')
                     ->select('id','slug','image','title','status','created_at')->get()->map(function($allcommunity){
					$allcommunity->id=$allcommunity->id;
					$allcommunity->title=$allcommunity->title;
					$allcommunity->slug=$allcommunity->slug;
					$allcommunity->status=$allcommunity->status;
					$allcommunity->created_at=$allcommunity->created_at;
				    $allcommunity->image = route('home.dashboard').'/public/category/'.$allcommunity->image;
				    return $allcommunity;
				   });
        $Json['category']=$allcategory;
		return response()->json(array($Json));
		die;
    }

    public function user_activity(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			if($request->isMethod('post'))
			{
				$posts2=DB::table('user_activity')
		    		   ->leftjoin('user_posts','user_posts.id','user_activity.post_id')
		    		   ->leftjoin('community','community.id','user_posts.community_id')
		    		   ->leftjoin('users','users.id','user_posts.user_id')
		    		   ->leftjoin('posts_likes','posts_likes.post_id','user_activity.like_id')
		    		   ->leftjoin('user_comments','user_comments.post_id','user_activity.comment_id')
		               ->where('user_posts.user_id',$user->id)
		               ->where('user_activity.user_id',$user->id)
		    		   ->select('user_activity.*','users.name as username','posts_likes.like','user_comments.comment','user_activity.created_at as postdate','community.title as community','user_posts.media','user_posts.post','user_posts.title as posttitle','user_posts.slug','user_posts.id as postid','community.image as commimage')
		    		   ->groupBy('user_activity.id')
		               ->orderBy('user_activity.id','DESC')
		    	       ->get()
		               ->toArray();
		        $posts1= DB::table('user_activity')
		               ->leftjoin('community','community.id','user_activity.post_id')
		               ->leftjoin('community_join','community.id','community_join.community_id')
		               ->leftjoin('users','users.id','community_join.user_id')
		               ->where('community_join.user_id',$user->id)
		               ->where('user_activity.user_id',$user->id)
		               ->select('user_activity.*','users.name as username','community.title as community','community.image as commimage','user_activity.created_at as postdate')
		               ->groupBy('user_activity.id')
		               ->orderBy('user_activity.id','DESC')
		               ->get()
		               ->toArray();   
		        $posts=array_merge($posts1,$posts2);
		        $useractivity=array();
		        foreach ($posts as $key => $value) 
		        {
		        	$activity['image']=route('home.dashboard').'/public/community/'.$value->commimage;
		        	$activity['status']=$value->status;
		        	$activity['type']=$value->type;
		        	$activity['community']=$value->community;
		        	$activity['created_at']=date('d-m-y',strtotime($value->postdate));	
		        	$useractivity[]=$activity;
		        }
		            if(count($posts)==0)
		            {
		            	$Json['status']=true;
		            	$Json['msg']='No activity found';
		            }else
		            {
		            	$Json['status']=true;
		            	$Json['activity']=$useractivity;
    			        $Json['msg']='User activity fetched successfully';
		            }
    			    return response()->json(array($Json));
    			    die;
    	    }else
			{
    	  		$Json['status']=false;
    			$Json['msg']='Unauthorized Request';
    			return response()->json(array($Json));
    			die;
    	    }
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function search_news(Request $request)
    {
    	if($request->isMethod('post'))
		{
			$rules=array(
	            'title' => 'required',
	           );
			   $messages=array(
			        'title.required' => 'Please enter title.'
			    );
		        $validator=\Validator::make($request->all(),$rules,$messages);
		        if($validator->fails())
		        {
		            $Json['status']=false;
			        $Json['title'] = 'Title is required';  
			        return response()->json(array($Json));
			        die;
		        }
			if($request->title)
	        {
	            $userpost=UserPost::
	                     leftjoin('users','users.id','user_posts.user_id')
	                    ->leftjoin('community','community.id','user_posts.community_id')
	                    ->select('user_posts.*','users.name as username','users.email as useremail','community.title as community','community.image')
	                    ->orWhere('user_posts.title', 'LIKE', "%{$request->title}%")
	                    ->orWhere('user_posts.post', 'LIKE', "%{$request->title}%")
	                    ->orWhere('user_posts.slug', 'LIKE', "%{$request->title}%")
	                    ->orWhere('user_posts.question', 'LIKE', "%{$request->title}%")
	                    ->get();
	            $usercommunty=\DB::table('community')
	                         ->orWhere('title', 'LIKE', "%{$request->title}%")
	                         ->orWhere('description', 'LIKE', "%{$request->title}%")
	                         ->get();        
	        }else
	        {
	            $userpost=[];
	            $usercommunty=[];
	        } 
	         $Json['status']=true;
			 $Json['post']=$userpost;
			 $Json['community']=$usercommunty;
			 return response()->json(array($Json));
			 die;
    	}else
		{
	  		$Json['status']=false;
			$Json['msg']='Unauthorized Request';
			return response()->json(array($Json));
			die;
	    }
    }

    public function continentcat(Request $request)
    {
    	$category=\DB::table('category')->where('continent',1)->get();
    	if(count($category)>0)
    	{
    		$Json['status']=true;
		    $Json['category']=$category;
    	}else
    	{
    		$Json['status']=false;
		    $Json['category']='No data found';
    	}
    	
		return response()->json(array($Json));
		die;
    }
    public function trending(Request $request)
    {
    	if($request->header('Authorization'))
		   {
		   	$auth_key = $request->header('Authorization');
            if(isset($auth_key) && $auth_key != "") {
                $dataa = explode(" ",$auth_key);
                if(isset($dataa[1]))
                {
                    $main_key = $dataa[1];
                }else{
                    $main_key = $auth_key;
                }
            }
                $user = User::where('auth_key', $main_key)->first();
            }else
            {
            	$user=array();
            }
    	
    	$userpost=UserPost::
                 leftjoin('user_comments','user_comments.post_id','user_posts.id')
                 ->leftjoin('users','users.id','user_posts.user_id')
                 ->leftjoin('community','community.id','user_posts.community_id')
                 ->leftjoin('user_detail','user_detail.user_id','user_posts.user_id')
                 ->select('user_posts.*','users.name as username','users.email as useremail','community.title as community','user_detail.image as userimg',\DB::raw('count(user_comments.post_id) as post_count'))
                 ->groupBy('user_comments.post_id')
                 ->orderBy('user_posts.id','DESC')
                 ->get();

    	if(count($userpost)>0)
    	{
			$trending=UserPost::
                 leftjoin('user_comments','user_comments.post_id','user_posts.id')
                 ->leftjoin('users','users.id','user_posts.user_id')
                 ->leftjoin('community','community.id','user_posts.community_id')
                 ->leftjoin('user_detail','user_detail.user_id','user_posts.user_id')
                 ->select('user_posts.id as postid','user_posts.type','user_posts.title','user_posts.slug','user_posts.post','user_posts.media','user_posts.question','user_posts.queoption','user_posts.created_at','users.name as username','users.email as useremail','community.title as community','community.id as community_id','user_detail.image as userimg',\DB::raw('count(user_comments.post_id) as post_count'))
                 ->groupBy('user_comments.post_id')
                 ->orderBy('user_posts.id','DESC')->get();
                 foreach($trending as $allcommunity)
                 {

                 	$totallike=DB::table('posts_likes')->where('post_id',$allcommunity->postid)->where('like',1)->count();
                 	$totalcomment=DB::table('user_comments')->where('post_id',$allcommunity->postid)->count();

                 	if(!empty($user))
                 	{
                 		$likepost=DB::table('posts_likes')->where('post_id',$allcommunity->postid)->where('like',1)->where('user_id',$user->id)->first();

                 		$userpost=DB::table('user_posts')->where('id',$allcommunity->postid)->where('user_id',$user->id)->first();
	             		if(!empty($userpost))
	             		{

	             			$allcommunity->user_post=1;
	             		}else
	             		{
	             			$allcommunity->user_post=0;
	             		}
	             		if(!empty($likepost))
					    {
					    	$allcommunity->islike=true;
					    }else
					    {
					    	$allcommunity->islike=false;
					    }
                 	}else
                 	{
                 		$allcommunity->islike=false;
                 	}
             		
					$allcommunity->post_id=$allcommunity->postid;
					$allcommunity->community_id=$allcommunity->community_id;
					$allcommunity->username=$allcommunity->username;
					$allcommunity->useremail=$allcommunity->useremail;
					$allcommunity->community=$allcommunity->community;
					if(!empty($allcommunity->userimg))
					{
						$allcommunity->userimg=route('home.dashboard').'/public/user/images/'.$allcommunity->userimg;
					}else
					{
						$allcommunity->userimg=route('home.dashboard').'/public/images/user.png';;
					}
					
					$allcommunity->slug = $allcommunity->slug;
				    $allcommunity->type = $allcommunity->type;
				    if($allcommunity->type=='post')
				    {
				    $allcommunity->title = $allcommunity->title;
				    $allcommunity->post = strip_tags($allcommunity->post);
				    $allcommunity->media = route('home.dashboard').'/public/post/'.$allcommunity->media;
				    }else
				    {
				    	$allcommunity->question = $allcommunity->question;
				    	
				    	$options=explode('-',$allcommunity->queoption);
					    $alloption=[];
				    	foreach ($options as $key => $val)
				    	{
				    		$qoption=trim($val);
				    		$newoption=str_replace('["', '', $qoption);
				    		$newoption1=str_replace('"', '', $newoption);
				    		$newoption2['key']=str_replace(']', '', $newoption1);
				    		$alloption[]=$newoption2;
				    	}
				        $allcommunity->queoption = $alloption;
				    }
				    $allcommunity->created_at=$allcommunity->created_at;
				    $allcommunity->like=$totallike.' likes';
				    $allcommunity->comment=$totalcomment.' comments';
				    
				    $randnum=\Helper::RandNum('5').$allcommunity->postid;
				    $community=$allcommunity->community;
				    $urllink=url('/').'/'.$community.'/comments/'.$randnum.'/'.$allcommunity->slug;

				    $allcommunity->copy=$urllink;
				    if(!empty($allcommunity->title))
					 {
					 	$title=$allcommunity->title;
					 }else
					 {
					 	$title='IF I WERE...MAKING THE WORLD A BETTER PLACE';
					 }
					 
					 if(!empty($allcommunity->media))
					 {
					 	$media=route('home.dashboard').'/public/post/'.$allcommunity->media;
					 }else
					 {
					 	$media=route('home.dashboard').'/public/images/logo.png';
					 }
					 
					 $img=urlencode($media);

				 	$titleweb=urlencode($title);
				 	
				 
				    $allcommunity->facebook="http://www.facebook.com/sharer.php?s=100&p[url]=".$urllink."&p[images][0]=$img&p[title]=$titleweb&p[summary]='If I Were'";
				    $allcommunity->twitter="https://twitter.com/share?url=".$urllink."&text=IF I WERE...MAKING THE WORLD A BETTER PLACE check this post";
				    $allcommunity->linkedin="https://www.linkedin.com/shareArticle?mini=true&url=".$urllink."&title=$allcommunity->slug&summary=IF I WERE...MAKING THE WORLD A BETTER PLACE check this post&source=IF I WERE...MAKING THE WORLD A BETTER PLACE";
				    $trendingpost[]=$allcommunity;
			   }
			
    		$Json['status']=true;
    		$Json['trending']=$trendingpost;
    	}else
    	{
    		$Json['status']=false;
		    $Json['category']='No data found';
    	}
    	
		return response()->json(array($Json));
		die;
    }

    public function allfaq(Request $request)
    {
    	$allfaq=Faq::get();
    	if(count($allfaq)>0)
    	{
    		$faq=Faq::
                 get()->map(function($allcommunity){
					$allcommunity->id=$allcommunity->id;
					$allcommunity->type=$allcommunity->type;
					$allcommunity->question=$allcommunity->question;
					$allcommunity->answer = $allcommunity->answer;
				    $allcommunity->created_at=$allcommunity->created_at;
				    return $allcommunity;
				   });
	        $Json['status']=true;
		    $Json['faq']=$faq;
    	}else
    	{
    		$Json['status']=false;
		    $Json['category']='No data found';
    	}
    	
		return response()->json(array($Json));
		die;
    }

    public function subcategory(Request $request)
    {
    	if($request->isMethod('post'))
		{
	    	$subcat=\DB::table('subcategory')
	                ->leftjoin('category','category.id','subcategory.cat_id')
	                ->where('subcategory.cat_id',$request->cat_id)
	                ->select('category.title as category','subcategory.id','subcategory.cat_id','subcategory.name','subcategory.image','subcategory.created_at')
	                ->groupBy('subcategory.id')
	                ->get()
	                ->map(function($allcat){
						$allcat->category=$allcat->category;
						$allcat->id=$allcat->id;
						$allcat->cat_id=$allcat->cat_id;
						$allcat->name=$allcat->name;
						$allcat->image = route('home.dashboard').'/public/subcat/'.$allcat->image;
					    $allcat->created_at=$allcat->created_at;
					    return $allcat;
					   });
	        if(!empty($subcat))
	        {
	        	$Json['status']=true;
			    $Json['subcategory']=$subcat;
	        }else
	        {
	        	$Json['status']=false;
			    $Json['subcategory']='No data found';
	        }
	        return response()->json(array($Json));
        }else
		{
	  		$Json['status']=false;
			$Json['msg']='Unauthorized Request';
			return response()->json(array($Json));
			die;
	    }
    }

    public function subcommunity(Request $request)
    {
    	$subcommunity=Community::where('cat_id',$request->cat_id)
    	          ->where('subcat_id',$request->subcat_id)
    	          ->get()->map(function($community){
    	          	$community->description=strip_tags($community->description);
    	          	$community->image=route('home.dashboard').'/public/community/'.$community->image;
    	          	$community->cover_image=route('home.dashboard').'/public/community/'.$community->cover_image;
			    return $community;
			   });
    	if(!empty($subcommunity))
	        {
	        	$Json['status']=true;
			    $Json['subcommunity']=$subcommunity;
	        }else
	        {
	        	$Json['status']=false;
			    $Json['subcommunity']='No data found';
	        }
	        return response()->json(array($Json));
    }



}
