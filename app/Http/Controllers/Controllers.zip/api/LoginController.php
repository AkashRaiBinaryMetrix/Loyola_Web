<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Models\User;
use App\Models\EmailTemplate;
use App\Helpers\Helper;
use Hash;
use DB;
use App\Models\UserLocation;
use Stevebauman\Location\Facades\Location;

class LoginController extends Controller
{
    public function signup(Request $request)
    {
    	if ($request->isMethod('post'))
    	{
	    	$json=array();
		    $input=$request->all();
		    $email=$input['email'];
		    $emailcheck = true;
		      if($email!=""){
		          $emailcheck=Helper::checkEmail($input['email']);
		      }
		      if($emailcheck==true){
		          $insertdata['name']=$input['username'];
		          $insertdata['email']=$email;
		          $insertdata['password']=Hash::make($input['password']);
		          $insertdata['auth_key']=md5(Hash::make($input['password']));
		          $insertdata['role_id']=2;
		          $finddata1=User::where('email',$input['email'])->first();
		          if(!empty($finddata1->email)){
		              $Json['status']=false;
		            $Json['msg']='The email id you have entered is already exist';
		            return response()->json(array($Json));
		            die;
		          }else{
	                  if($input['password']==$input['confirmpassword']){
	                  	if(!preg_match('/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,15}$/', $input['password'])) 
	                  	{
	                  	   $Json['status']=false;
		                   $Json['msg']='Password should contain at least one numeric digit and a special character and length between 7 to 15 characters';
		                   return response()->json(array($Json));
		                   die;
	                    }
	                    $title='If i were';
			            $subject='Acknowledgement of Registration';
			            $emailtemp = EmailTemplate::first();
			            $message=$emailtemp->welcome_note;
			            $emailtemp=encrypt($request->email);
			            $route=url('confirm-email/'.$emailtemp);
			            $link='<a href="'.$route.'">Confirm Your Email</a>';
			            
			            if(strpos($message, '[USER]') !== false && strpos($message, '[EMAIL]') !== false && strpos($message, '[LINK]') !== false)
			            {
			                $messagenew11=str_replace('[LINK]',$link,$message);
			                $messagenew1=str_replace('[EMAIL]',$request->email,$messagenew11);
			                $messagenew=str_replace('[USER]',ucwords($request->name),$messagenew1);
			            }
			            else
			            {
			                $messagenew=$message;
			            }
			           
			            $to=$request->email;
		              
		            Helper::sendemail($subject,$title,$messagenew,$to);
		            $userid=DB::table('users')->insertGetId($insertdata);
		            $ip = $request->ip();
			        $currentUserInfo = Location::get($ip);
			        if(!empty($currentUserInfo))
			        {
			            $userlocation=new UserLocation;
			            $userlocation->user_id=$userid;
			            $userlocation->country=$currentUserInfo->countryName;
			            $userlocation->timezone=$currentUserInfo->timezone;
			            $userlocation->state=$currentUserInfo->regionName;
			            $userlocation->city=$currentUserInfo->cityName;
			            $userlocation->zipcode=$currentUserInfo->zipCode;
			            $userlocation->ip=$currentUserInfo->ip;
			            $userlocation->created_at=\Carbon\Carbon::now();
			            $userlocation->save();
			        }
		            $Json['status'] = true;
		            $Json['msg'] = 'Thanks for registering with us a confirmation email has been sent to you.';
		            return response()->json(array($Json));
		                        }
		              else{
		                $Json['status']=false;
		                $Json['msg']='Sorry,password and confirm password does not match';
		                return response()->json(array($Json));
		                  die;
		              }
		       
		               }
		      }else{
		        $Json['status']=false;
		        $Json['msg'] = 'Invalid email format'; 
		        return response()->json(array($Json));
		        die;
		      }
		}else{
	      $Json['status']=false;
	      $Json['msg']='Unauthorized Request';
	      return response()->json(array($Json));
	      die;
	    }
    }

    public function login(Request $request)
    {
    	if ($request->isMethod('post'))
    	{
	    	$json=array();
		    $input=$request->all();
		    $email=$input['email'];
		    $password=$input['password'];
		    $emailcheck = true;
		      if($email!="")
		      {
		          $emailcheck=Helper::checkEmail($input['email']);
		      }
		      if($emailcheck==true)
		      {
		      	$find=User::where('email',$email)->first();
		      	if(empty($find))
		      	{
		      		$Json['status']=false;
			        $Json['msg'] = 'This email id is not exist'; 
			        return response()->json(array($Json));
			        die;
		      	}else
		      	{
		      		if(Hash::check($password, $find->password))
		      		{
		      			if($find->user_status!='0' || $find->reject_status!=0)
		      			{
		      				if($find->email_verified_at==NULL)
		      				{
		      					$Json['status']=true;
					            $Json['msg']='Your Email Id is not verified';
					            return response()->json(array($Json));
					            die;
		      				}
		      				$Json['status']=true;
				            $Json['auth_key']='Bearer '.$find->auth_key;
				            $Json['msg']='Login Successfully';
				            return response()->json(array($Json));
				            die;
		      			}else
		      			{
		      				$Json['status']=false;
					        $Json['msg']='You cannot login now in this account. Please contact to administrator';
					        return response()->json(array($Json));
					        die;
		      			}
		      		}else
		      		{
				        $Json['status']=false;
				        $Json['msg']='Invalid password';
				        return response()->json(array($Json));
				        die;
			        }
		      	}
		      	
		      }else{
		      	
		        $Json['status']=false;
		        $Json['msg'] = 'Invalid email format'; 
		        return response()->json(array($Json));
		        die;
		      }
		}else{
	      $Json['status']=false;
	      $Json['msg']='Unauthorized Request';
	      return response()->json(array($Json));
	      die;
	    }
    }

    public function forgot_password(Request $request)
    {
    	if ($request->isMethod('post'))
    	{
	    	$json=array();
		    $input=$request->all();
		    
		    $rules=array(
            'email' => 'required',
        );
		   $messages=array(
		        'email.required' => 'Please enter email id.'
		    );
		        $validator=\Validator::make($request->all(),$rules,$messages);
		        if($validator->fails())
		        {
		            $Json['status']=false;
			        $Json['msg'] = 'Email id is required'; 
			        return response()->json(array($Json));
			        die;
		        }
		    $email=$input['email'];
		    $emailcheck = true;
		      if($email!="")
		      {
		          $emailcheck=Helper::checkEmail($input['email']);
		      }
		      if($emailcheck==true)
		      {
		      	$find=User::where('email',$email)->first();
		      	if(empty($find))
		      	{
		      		$Json['status']=false;
			        $Json['msg'] = 'This email id is not exist'; 
			        return response()->json(array($Json));
			        die;
		      	}else
		      	{
	      			if($find->user_status!='0')
	      			{
	      				if($find->email_verified_at==NULL)
		      			{
		      					$Json['status']=true;
					            $Json['msg']='Your Email Id is not verified';
					            return response()->json(array($Json));
					            die;
		      			}
	      				$otp=rand(1111,9999);
			            $currettime=\Carbon\Carbon::now()->timestamp;
			            $time1=\Carbon\Carbon::now()->addMinutes(30);
			            $time=$time1->timestamp;
			            
			            User::where('email',$request->email)->update(['otp'=>$otp]);

			            $title='If i were';
			            $subject='Forgot Password Link';
			            $emailtemp = EmailTemplate::first();
			            $message=$emailtemp->forgot_password;
			            if(strpos($message, '[OTP]') !== false)
			            { 
			                $messagenew=str_replace('[OTP]',$otp,$message);  
			            }
			            else
			            {
			                $messagenew=$message;
			            }
			           
			            $to=$request->email;
			            $sendemail=\Helper::sendemail($subject,$title,$messagenew,$to);
			            $Json['status']=true;
				        $Json['msg']='One Time Password has been sent on your email id successfully';
				        return response()->json(array($Json));
				        die;
	      			}else
	      			{
	      				$Json['status']=false;
				        $Json['msg']='This account is not active';
				        return response()->json(array($Json));
				        die;
	      			}
		      	}
		      	
		      }else
		      {
		        $Json['status']=false;
		        $Json['msg'] = 'Invalid email format'; 
		        return response()->json(array($Json));
		        die;
		      }
		}else
		{
	      $Json['status']=false;
	      $Json['msg']='Unauthorized Request';
	      return response()->json(array($Json));
	      die;
	    }
    }

    public function checkotp(Request $request)
    {
    	if ($request->isMethod('post'))
    	{
	    	$json=array();
		    $input=$request->all();
		    
		    $rules=array(
            'email' => 'required',
            'otp' => 'required'
        );
		   $messages=array(
		        'email.required' => 'Please enter email id.',
		        'otp.required' => 'Please enter One Time Password(OTP).'
		    );
		        $validator=\Validator::make($request->all(),$rules,$messages);
		        if($validator->fails())
		        {
		            $Json['status']=false;
			        $Json['emailmsg'] = 'Email id is required'; 
			        $Json['otpmsg'] = 'OTP is required'; 
			        return response()->json(array($Json));
			        die;
		        }
		    $email=$input['email'];
		    $otp=$input['otp'];
		    $emailcheck = true;
		      if($email!="")
		      {
		          $emailcheck=Helper::checkEmail($input['email']);
		      }
		      if($emailcheck==true)
		      {
		      	$find=User::where('email',$email)->first();
		      	if(empty($find))
		      	{
		      		$Json['status']=false;
			        $Json['msg'] = 'This email id is not exist'; 
			        return response()->json(array($Json));
			        die;
		      	}else
		      	{
	      			if($find->user_status!='0')
	      			{
	      				if($find->email_verified_at==NULL)
		      			{
		      					$Json['status']=true;
					            $Json['msg']='Your Email Id is not verified';
					            return response()->json(array($Json));
					            die;
		      			}
		      			$checkotp=User::where('email',$email)->where('otp',$otp)->first();
	      				if(!empty($checkotp))
	      				{
	      					$Json['status']=true;
				            $Json['msg']='OTP Matched';
				            return response()->json(array($Json));
				            die;
	      				}else
	      				{
	      					$Json['status']=false;
				            $Json['msg']='Invalid OTP';
				            return response()->json(array($Json));
				            die;
	      				}
			            
	      			}else
	      			{
	      				$Json['status']=false;
				        $Json['msg']='This account is not active';
				        return response()->json(array($Json));
				        die;
	      			}
		      	}
		      	
		      }else
		      {
		        $Json['status']=false;
		        $Json['msg'] = 'Invalid email format'; 
		        return response()->json(array($Json));
		        die;
		      }
		}else
		{
	      $Json['status']=false;
	      $Json['msg']='Unauthorized Request';
	      return response()->json(array($Json));
	      die;
	    }
    }

    public function change_password(Request $request)
    {
    	if ($request->isMethod('post'))
    	{
	    	$json=array();
		    $input=$request->all();
		    
		    $rules=array(
            'email' => 'required',
            'password' => 'required',
            'confirmpassword' => 'required'
        );
		   $messages=array(
		        'email.required' => 'Please enter email id.',
		        'password.required' => 'Please enter Password.',
		        'confirmpassword.required' => 'Please enter confirm Password.'
		    );
		        $validator=\Validator::make($request->all(),$rules,$messages);
		        if($validator->fails())
		        {
		            $Json['status']=false;
			        $Json['emailmsg'] = 'Email id is required'; 
			        $Json['passwordmsg'] = 'Password is required'; 
			        $Json['confirmpasswordmsg'] = 'Confirm Password is required'; 
			        return response()->json(array($Json));
			        die;
		        }
		    $email=$input['email'];
		    $password=$input['password'];
		    $confirmpassword=$input['confirmpassword'];
		    $emailcheck = true;
		      if($email!="")
		      {
		          $emailcheck=Helper::checkEmail($input['email']);
		      }
		      if($emailcheck==true)
		      {
		      	$find=User::where('email',$email)->first();
		      	if(empty($find))
		      	{
		      		$Json['status']=false;
			        $Json['msg'] = 'This email id is not exist'; 
			        return response()->json(array($Json));
			        die;
		      	}else
		      	{
	      			if($find->user_status!='0')
	      			{
	      				if($find->email_verified_at==NULL)
		      			{
		      					$Json['status']=true;
					            $Json['msg']='Your Email Id is not verified';
					            return response()->json(array($Json));
					            die;
		      			}
		      			if($input['password']==$input['confirmpassword']){
	                  	if(!preg_match('/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,15}$/', $input['password'])) 
	                  	{
	                  	   $Json['status']=false;
		                   $Json['msg']='Password should contain at least one numeric digit and a special character and length between 7 to 15 characters';
		                   return response()->json(array($Json));
		                   die;
	                    }
		      			$checkotp=User::where('email',$email)->first();
	      				$insertdata['password']=Hash::make($password);
		                $insertdata['auth_key']=md5(Hash::make($password));
		                User::where('email',$email)->update($insertdata);
			            $Json['status']=true;
				        $Json['msg']='Password changed successfully';
				        return response()->json(array($Json));
				        die;
				      }else
		      		  {
		      				$Json['status']=false;
					        $Json['msg']='Sorry,password and confirm password does not match';
					        return response()->json(array($Json));
					        die;
		      		  }
	      			}else
	      			{
	      				$Json['status']=false;
				        $Json['msg']='This account is not active';
				        return response()->json(array($Json));
				        die;
	      			}
		      	}
		      	
		      }else
		      {
		        $Json['status']=false;
		        $Json['msg'] = 'Invalid email format'; 
		        return response()->json(array($Json));
		        die;
		      }
		}else
		{
	      $Json['status']=false;
	      $Json['msg']='Unauthorized Request';
	      return response()->json(array($Json));
	      die;
	    }
    }

    public function profile_edit(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
	    	if ($request->isMethod('post'))
	    	{
		    $input=$request->all();
		    
		      	$find=User::where('email',$user->email)->first();
		      	
	      			if($find->user_status!='0')
	      			{
	      				if($find->email_verified_at==NULL)
		      			{
		      					$Json['status']=true;
					            $Json['msg']='Your Email Id is not verified';
					            return response()->json(array($Json));
					            die;
					            
		      			}
		      			$checkuser=DB::table('user_detail')->where('user_id',$user->id)->first();
		      			
		      			if($request->hasFile('image'))
			            {
			            	$path= public_path('user/images/'.$find->image);
			                if(\File::exists($path))
			                {
			                  \File::delete($path);
			                }
			                $image = $request->file('image');
			                $image_name = 'user'.'-'.rand(1111,9999).'.'.$image->getClientOriginalExtension();
			                $destinationPath = public_path('user/images');
			                $image->move($destinationPath, $image_name);
			                $insertdata['image']=$image_name;
			            }
			            if(!empty($input['name']))
			            {
			            	$userdata['name']=$input['name'];
			            	User::where('id',$user->id)->update($userdata);
			            }
			            if(!empty($input['phone']))
			            {
			            	$insertdata['phone']=$input['phone'];
			            }
			            if(!empty($input['gender']))
			            {
			            	$insertdata['gender']=$input['gender'];
			            }
			            if(!empty($input['age']))
			            {
			            	$insertdata['age']=$input['age'];
			            }
			            if(!empty($input['city']))
			            {
			            	$insertdata['city']=$input['city'];
			            }
			            if(!empty($input['state']))
			            {
			            	$insertdata['state']=$input['state'];
			            }
			            if(!empty($input['country']))
			            {
			            	$insertdata['country']=$input['country'];
			            }
			            if(!empty($input['zipcode']))
			            {
			            	$insertdata['zipcode']=$input['pincode'];
			            }
			           

			            if(empty($checkuser))
		      			{
		      				if(!empty($insertdata))
			            	{
			            		$insertdata['user_id']=$user->id;
			            		$insertdata['created_at']=\Carbon\Carbon::now();
			            		$insertdata['updated_at']=\Carbon\Carbon::now();
			                    DB::table('user_detail')->insert($insertdata);
			                }
			            }else
			            {
			            	if(!empty($insertdata))
			            	{
			            		DB::table('user_detail')->where('user_id',$user->id)->update($insertdata);
			            	}	
			            }
			            $Json['status']=true;
				        $Json['msg']='User detail updated successfully';
				        return response()->json(array($Json));
				        die;
				     
	      			}else
	      			{
	      				$Json['status']=false;
				        $Json['msg']='This account is not active';
				        return response()->json(array($Json));
				        die;
				    }
	   
		      	
			}else
			{
		      $Json['status']=false;
		      $Json['msg']='Unauthorized Request';
		      return response()->json(array($Json));
		      die;
		    }
	    }else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function update_password(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
	    	if ($request->isMethod('post'))
	    	{
		        $input=$request->all();
		      	$find=User::where('email',$user->email)->first();
		      	if(!Hash::check($request->oldpassword,$find->password))
	            { 
	            	$Json['status']=false;
			        $Json['msg']='Old Password not matched';
			        return response()->json(array($Json));
	            }

	            if($request->password!=$request->confirm_password)
	            {
	            	$Json['status']=false;
			        $Json['msg']='Password and confirm password not matched';
			        return response()->json(array($Json));
	            }
	            if($request->password==$request->confirm_password)
	            {
	                 if(!preg_match('/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,15}$/', $input['password'])) 
	                  	{
	                  	   $Json['status']=false;
		                   $Json['msg']='Password should contain at least one numeric digit and a special character and length between 7 to 15 characters';
		                   return response()->json(array($Json));
		                   die;
	                    }
	                   $password=\Hash::make($request->password);
                       User::where('email',$user->email)->update(['password'=>$password,'updated_at'=>\Carbon\Carbon::now()]);
                       $Json['status']=true;
			           $Json['msg']='Password changed successfully!';
			           return response()->json(array($Json));  
	            }
            
	    	}else
				{
			      $Json['status']=false;
			      $Json['msg']='Unauthorized Request';
			      return response()->json(array($Json));
			      die;
			    }
	    }else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function logout(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
			$check=User::where('id',$user->id)->where('auth_key',$user->auth_key)->update(['auth_key'=>NULL]);
			if($check)
			{
				$Json['status']=true;
				$Json['msg']='User logout successfully';
				return response()->json(array($Json));
			    die;
			}
			
		}else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function user_profile(Request $request)
    {
    	$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
	    	if ($request->isMethod('post'))
	    	{
	    		$user=DB::table('users')
	    			  ->leftjoin('user_detail','user_detail.user_id','users.id')
	    			  ->where('users.id',$user->id)
	    			  ->select('users.id','users.name','users.email','user_detail.phone','user_detail.gender','user_detail.age','user_detail.city','user_detail.state','user_detail.country','user_detail.zipcode','user_detail.image')
	    			  ->groupBy('users.id')
	    			  ->first();
	    		$userdetail['id']=$user->id;
	    		$userdetail['name']=$user->name;
	    		$userdetail['email']=$user->email;
	    		$userdetail['phone']=$user->phone;
	    		$userdetail['gender']=$user->gender;
	    		$userdetail['age']=$user->age;
	    		$userdetail['city']=$user->city;
	    		$userdetail['state']=$user->state;
	    		$userdetail['country']=$user->country;
	    		$userdetail['zipcode']=$user->zipcode;
	    		if(!empty($user->image))
	    		{
	    			$userdetail['image']=route('home.dashboard').'/public/user/images/'.$user->image;
	    		}else
	    		{
	    			$userdetail['image']=route('home.dashboard').'/public/images/user.png';
	    		}
	    		
	    		$Json['status']=true;	  
	    		$Json['user']=$userdetail;
	    		return response()->json(array($Json));	  
    		}else
			{
		      $Json['status']=false;
		      $Json['msg']='Unauthorized Request';
		      return response()->json(array($Json));
		      die;
		    }
	    }else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
    }

    public function baseurl()
    {
    	$Json=array();
    	$url=route('home.dashboard');
    	$Json['status']=true;	  
		$Json['base_url']=$url;
		return response()->json(array($Json));	
		return response()->json(array($Json));
    }

    
    
}
