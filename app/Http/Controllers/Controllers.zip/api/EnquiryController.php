<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Helpers\Helper;
use App\Models\Enquiry;
use DB;

class EnquiryController extends Controller
{
	public function contactus(Request $request)
	{
		if($request->isMethod('post'))
		{
			$json=array();
			$rules=array(
	            'first_name' => 'required',
	            'last_name' => 'required',
	            'emailid' => 'required',
	            'phone' => 'required',
	            'message' => 'required'
	           );
			   $messages=array(
			        'first_name.required' => 'Please enter first name.',
			        'last_name.required' => 'Please enter last name.',
			        'emailid.required' => 'Please enter email id.',
			        'phone.required' => 'Please enter phone no.',
			        'message.required' => 'Please enter message.',
			    );
		        $validator=\Validator::make($request->all(),$rules,$messages);
		        if($validator->fails())
		        {
		            $Json['status']=false;
			        $Json['first_name'] = 'First name is required'; 
			        $Json['last_name'] = 'Last name is required'; 
			        $Json['emailid'] = 'Email id is required'; 
			        $Json['phone'] = 'Phone is required'; 
			        $Json['message'] = 'Message is required'; 
			        return response()->json(array($Json));
			        die;
		        }

		    $input=$request->all();
		    $firstname=$input['first_name'];
		    $lastname=$input['last_name'];
		    $emailid=$input['emailid'];
		    $phone=$input['phone'];
		    $message=$input['message'];
		    if($emailid!="")
		    {
		          $emailcheck=Helper::checkEmail($input['emailid']);
		    }
		      if($emailcheck==true)
		      {
		      	if(preg_match('/^([0-9]*)$/', $phone))
		      	{
				    $enquiry=new Enquiry;
			        $enquiry->first_name=$firstname;
			        $enquiry->last_name=$lastname;
			        $enquiry->email=$emailid;
			        $enquiry->phone=$phone;
			        $enquiry->message=$message;
			        $enquiry->save();
					$Json['status']=true;
					$Json['msg']='Your enquiry submitted Successfully!';
					return response()->json(array($Json));
					die;
				}else
				{
					$Json['status']=false;
					$Json['msg']='Only numbers are allowed';
					return response()->json(array($Json));
				}
			   }else{
		        $Json['status']=false;
		        $Json['msg'] = 'Invalid email format'; 
		        return response()->json(array($Json));
		        die;
		      }
		}else
		{
	  		$Json['status']=false;
			$Json['msg']='Unauthorized Request';
			return response()->json(array($Json));
			die;
	    }
	}

	public function invite_friends(Request $request)
	{
		$user = Helper::isAuthorize($request);
		$Json=array();
		if(!empty($user) && $user->user_status!='0')
		{
				if($request->isMethod('post'))
				{
				$json=array();
				$rules=array(
		            'first_name' => 'required',
		            'last_name' => 'required',
		            'emailid' => 'required'
		           );
				   $messages=array(
				        'first_name.required' => 'Please enter first name.',
				        'last_name.required' => 'Please enter last name.',
				        'emailid.required' => 'Please enter email id.',
				    );
			        $validator=\Validator::make($request->all(),$rules,$messages);
			        if($validator->fails())
			        {
			            $Json['status']=false;
				        $Json['first_name'] = 'First name is required'; 
				        $Json['last_name'] = 'Last name is required'; 
				        $Json['emailid'] = 'Email id is required'; 
				        return response()->json(array($Json));
				        die;
			        }

			    $input=$request->all();
			    $firstname=$input['first_name'];
			    $lastname=$input['last_name'];
			    $emailid=$input['emailid'];
			    if($emailid!="")
			    {
			          $emailcheck=Helper::checkEmail($input['emailid']);
			    }
			      if($emailcheck==true)
			      {
				        $invite['user_id']=$user->id;
				        $invite['first_name']=$firstname;
				        $invite['last_name']=$lastname;
				        $invite['friend_email']=$emailid;
				        $invite['created_at']=\Carbon\Carbon::now();
				        $invite['updated_at']=\Carbon\Carbon::now();
				        DB::table('user_invitation')->insert($invite);
				        $invitation='<a href="'.route('home.dashboard').'">'.route('home.dashboard').'</a>';
				        $title='If i were';
			            $subject='Invitation Link';
			            $messagenew='<html><head><body>';
			            $messagenew.='<p>Hello,</p><p>Please join our community for exploring new things</p><p>Click on the link for more info</p><p>'.$invitation.'</p><p>Best Wishes!</p><p>Thank you</p>';
			                $messagenew.='</body></html>';          
			            $to=$request->email;
			            $sendemail=\Helper::sendemail($subject,$title,$messagenew,$to);
						$Json['status']=true;
						$Json['msg']='Your invitation send Successfully!';
						return response()->json(array($Json));
						die;
				   }else{
			        $Json['status']=false;
			        $Json['msg'] = 'Invalid email format'; 
			        return response()->json(array($Json));
			        die;
			      }
			}else
			{
		  		$Json['status']=false;
				$Json['msg']='Unauthorized Request';
				return response()->json(array($Json));
				die;
		    }
	    }else
		{
        	$Json['status']=false;
			$Json['msg']='Sorry,You can not access this page';
			return response()->json(array($Json));
		    die;
		}
	}

	public function explore_videos(Request $request)
	{
		$videos=DB::table('videos')->get();
		$Json['status']=true;
		$Json['video']=$videos;
		return response()->json(array($Json));
	}


}
