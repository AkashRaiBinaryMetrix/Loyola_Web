<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use File;

class CategoryController extends Controller
{
    public function add_category(Request $request)
    {
    	if($request->isMethod('post'))
        {
        	$find=Category::where('continent_id',$request->continent)->where('title',$request->title)->first();
            if($find)
            {
                return redirect()->back()->with('error','Category already exist');
            }
        	$category= new Category;
        	$category->title=$request->title;
        	$category->status=$request->status;
            $category->continent_id=$request->continent;
        	$category->slug=str_slug($request->title);
            if($request->hasFile('image'))
            {
                $image = $request->file('image');
                $name = 'cat'.'-'.rand(1111,9999).'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/category');
                
                $image->move($destinationPath, $name);
                $category->image=$name;
            }
        	$category->created_at=\Carbon\Carbon::now();
        	$category->updated_at=\Carbon\Carbon::now();
        	$category->save();
        	return redirect()->back()->with('success','Category added successfully');
        }else
        {
            $continent=\DB::table('continents')->get();
        	return view('admin.category.add_category')->with(['continent'=>$continent]);
        }
    }

    public function manage_category()
    {
    	$category=Category::all();
    	return view('admin.category.manage_category')->with(['category'=>$category]);
    }

    public function edit_category(Request $request,$id)
    {
    	$newid=decrypt($id);
    	if($request->isMethod('post'))
    	{
            $check=Category::where('id',$newid)->where('title',$request->title)->first();
            if(!empty($check))
            {
                
            }else
            {
                $checktitle=Category::where('continent_id',$request->continent)->where('title',$request->title)->first();
                if(!empty($checktitle))
                {
                    return redirect()->back()->with('error','Category already exist!');
                }  
            }
    		$category= Category::where('id',$newid)->first();
        	$category->title=$request->title;
        	$category->status=$request->status;
            $category->continent_id=$request->continent;
            if($request->hasFile('image'))
            {
                $path=public_path('/category/'.$category->image);
                if(File::exists($path))
                {
                    File::delete($path);
                }
                $image = $request->file('image');
                $name = 'cat'.'-'.rand(1111,9999).'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/category');
                
                $image->move($destinationPath, $name);
                $category->image=$name;
            }
        	$category->slug=str_slug($request->title);
        	$category->updated_at=\Carbon\Carbon::now();
        	$category->save();
        	return redirect()->back()->with('success','Category edited successfully');
    	}else
    	{

    		$category=Category::where('id',$newid)->first();
            $continent=\DB::table('continents')->get();
    	    return view('admin.category.edit_category')->with(['category'=>$category,'id'=>$id,'continent'=>$continent]);
    	}
    	
    }

    public function delete_category($id)
    {
    	$id=decrypt($id);
    	$category=Category::where('id',$id)->delete();
        \DB::table('subcategory')->where('cat_id',$id)->delete();
        \DB::table('community')->where('cat_id',$id)->delete();
    	return redirect()->back()->with('success','Category deleted successfully');
    }
}
