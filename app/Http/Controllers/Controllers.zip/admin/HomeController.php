<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Community;
use App\Models\UserPost;
use App\Models\Post;

class HomeController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $totalusers=User::where('role_id',2)->count();
        $totalcommunity=Community::count();
        $totalposts=UserPost::count();
        $totaladminpost=Post::count();
        return view('admin.dashboard',['user'=>$totalusers,'community'=>$totalcommunity,'post'=>$totalposts,'totaladminpost'=>$totaladminpost]);
    }
}

