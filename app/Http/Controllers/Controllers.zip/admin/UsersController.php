<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Hash;
use App\Models\Role;
use Illuminate\Support\Facades\Validator;

class UsersController extends Controller
{
    public function index()
    {
        $users=User::
               leftJoin('roles','roles.id','users.role_id')
               ->select('users.*','roles.name as role_name')
               ->where('users.role_id','!=','1')
               ->get();      
        return view('admin.users.manage_users')->with(['users'=>$users]);
    }

    public function add(Request $request)
    {
        if($request->isMethod('post'))
        {
            $validator= Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|unique:users',
            'password' => 'required',
            'confirm_password' => 'required',
            'role_id' => 'required',
            ]);

            if ($validator->fails()) {
            return redirect()
                        ->back()
                        ->withInput($request->all())
                        ->withErrors($validator);
        }
            $check=User::where('email',$request->email)->first();
            if(!empty($check))
            {
                return redirect()->back()->with('error','Email id already exist!');
            }else if($request->password!=$request->confirm_password)
            {
                return redirect()->back()->with('error','Password and Confirm password not matched!');
            }else
            {
                $newuser= new User;
                $newuser->name=$request->name;
                $newuser->email=$request->email;
                $newuser->role_id=$request->role_id;
                $newuser->password=Hash::make($request->password);
                $newuser->created_at=\Carbon\Carbon::now();
                $newuser->updated_at=\Carbon\Carbon::now();
                $newuser->save();
                return redirect()->back()->with('success','User created successfully!');
            }
        }else
        {
            $roles=Role::all();
            return view('admin.users.add_users')->with(['roles'=>$roles]);
        }
    }

    public function edit(Request $request,$id)
    {
        if($request->isMethod('post'))
        {
            
            $newuser= User::where('email',$request->email)->first();
            $newuser->name=$request->name;
            $newuser->email=$request->email;
            $newuser->role_id=$request->role_id;
            $newuser->updated_at=\Carbon\Carbon::now();
            $newuser->save();
            return redirect()->back()->with('success','User details edited successfully!');
        }else
        {
            $newid=decrypt($id);
            $user=User::where('id',$newid)->first();
            $roles=Role::all();
            return view('admin.users.edit_user_details')->with(['user'=>$user,'roles'=>$roles]);
        }
    }

    public function delete($id)
    {
        $newid=decrypt($id);
        $check=User::where('id',$newid)->delete();
        \DB::table('admin_poll_votes')->where('user_id',$newid)->delete();
        \DB::table('community_join')->where('user_id',$newid)->delete();
        \DB::table('posts_likes')->where('user_id',$newid)->delete();
        \DB::table('post_hide')->where('user_id',$newid)->delete();
        \DB::table('user_activity')->where('user_id',$newid)->delete();
        \DB::table('user_comments')->where('user_id',$newid)->delete();
        \DB::table('user_community')->where('user_id',$newid)->delete();
        \DB::table('user_detail')->where('user_id',$newid)->delete();
        \DB::table('user_invitation')->where('user_id',$newid)->delete();
        \DB::table('user_poll')->where('user_id',$newid)->delete();
        \DB::table('user_posts')->where('user_id',$newid)->delete();
        \DB::table('user_post_reports')->where('user_id',$newid)->delete();
        return redirect()->back()->with('success','User details deleted successfully!');
    }

    public function user_status(Request $request)
    {
        
        $newid=$request->id;
        $statusnew=$request->status;

        if($statusnew=='reject')
        {  
           $check=User::where('id',$newid)->update(['reject_status'=>0]);
           User::where('id',$newid)->update(['user_status'=>0]);
           return 1;
        }
        if($statusnew=='approve')
        {  
           $check=User::where('id',$newid)->update(['reject_status'=>1]);
           return 1;
        }
        if($statusnew=='active')
        {  
           $check=User::where('id',$newid)->update(['user_status'=>1]);
           return 1;
        }
        if($statusnew=='deactive')
        {  
           $check=User::where('id',$newid)->update(['user_status'=>0]);
           return 1;
        }


    }

    public function addrole(Request $request)
    {
        if($request->isMethod('post'))
        {
            $validated = $request->validate([
            'name' => 'required|unique:roles',
            'slug' => 'required',
            ]);
            $role=new Role;
            $role->name=$request->name;
            $role->slug=$request->slug;
            $role->created_at=\Carbon\Carbon::now();
            $role->updated_at=\Carbon\Carbon::now();
            $role->save();
            return redirect()->back()->with('success','User role created successfully!');
        }else
        {
            return view('admin.users.add_role');
        }
    }

    public function manage_roles()
    {
        $roles=Role::all();
        return view('admin.users.manage_user_roles')->with(['roles'=>$roles]);
    }

    public function deleterole($id)
    {
        $newid=decrypt($id);
        Role::where('id',$newid)->delete();
        return redirect()->back()->with('success','User role deleted successfully!');
    }

    public function editrole(Request $request,$id)
    {
        $newid=decrypt($id);
        if($request->isMethod('post'))
        {
            $validated = $request->validate([
            'name' => 'required|unique:roles',
            'slug' => 'required',
            ]);
            $role=Role::where('id',$newid)->first();
            $role->name=$request->name;
            $role->slug=$request->slug;
            $role->updated_at=\Carbon\Carbon::now();
            $role->save();
            return redirect()->back()->with('success','User role edited successfully!');
        }else
        {
            $role=Role::where('id',$newid)->first();
            return view('admin.users.edit_user_role')->with(['role'=>$role]);
        }
    }

    public function user_permission(Request $request)
    {
        $userrole=Role::where('id','!=',1)->where('id','!=',2)->get();

        return view('admin.users.manage_user_permission')->with(['userrole'=>$userrole]);
    }

    public function manage_user_permission(Request $request,$name)
    {
        if($request->isMethod('post'))
        {
            $data=$request->all();

            if(!empty($request->Home))
            {
                    $permission['role_id']=$request->role_id;
                    $permission['title']=$data['Home']['name'];
                    if(!empty($data['Home']['view']))
                    {
                        $permission['view']=$data['Home']['view'];
                    }
                    

                $check=\DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['Home']['name'])->first();

                if(empty($check))
                {
                    \DB::table('roles_permissions')->insert($permission);
                }else
                {
                    \DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['Home']['name'])->update($permission);
                }   
            }
            
            if(!empty($request->Community))
            {
                    $Community['role_id']=$request->role_id;
                    $Community['title']=$data['Community']['name'];
                    if(!empty($data['Community']['view']))
                    {
                        $Community['view']=$data['Community']['view'];
                    }else
                    {
                        $Community['view']=NULL;
                    }
                    if(!empty($data['Community']['add']))
                    {
                    $Community['add']=$data['Community']['add'];
                    }else
                    {
                        $Community['add']=NULL;
                    }
                    if(!empty($data['Community']['manage']))
                    {
                    $Community['manage']=$data['Community']['manage'];
                    }else
                    {
                        $Community['manage']=NULL;
                    }
                    if(!empty($data['Community']['edit']))
                    {
                    $Community['edit']=$data['Community']['edit'];
                    }else
                    {
                        $Community['edit']=NULL;
                    }
                    if(!empty($data['Community']['delete']))
                    {
                    $Community['delete']=$data['Community']['delete'];
                    }else
                    {
                        $Community['delete']=NULL;
                    }
                    
                $checkcom=\DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['Community']['name'])->first();
                if(empty($checkcom))
                {
                    \DB::table('roles_permissions')->insert($Community);
                }else
                {
                    \DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['Community']['name'])->update($Community);
                }     
                   
            }
            if(!empty($request->Post))
            {
                    $Post['role_id']=$request->role_id;
                    $Post['title']=$data['Post']['name'];
                    if(!empty($data['Post']['view']))
                    {
                        $Post['view']=$data['Post']['view'];
                    }else
                    {
                        $Post['view']=NULL;
                    }
                    if(!empty($data['Post']['add']))
                    {
                    $Post['add']=$data['Post']['add'];
                    }else
                    {
                        $Post['add']=NULL;
                    }
                    if(!empty($data['Post']['manage']))
                    {
                    $Post['manage']=$data['Post']['manage'];
                    }else
                    {
                        $Post['manage']=NULL;
                    }
                    if(!empty($data['Post']['edit']))
                    {
                    $Post['edit']=$data['Post']['edit'];
                    }else
                    {
                        $Post['edit']=NULL;
                    }
                    if(!empty($data['Post']['delete']))
                    {
                    $Post['delete']=$data['Post']['delete'];
                    }else
                    {
                        $Post['delete']=NULL;
                    }
                $checkpost=\DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['Post']['name'])->first();
                if(empty($checkpost))
                {
                    \DB::table('roles_permissions')->insert($Post);
                }else
                {
                    \DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['Post']['name'])->update($Post);
                }     
            }
            if(!empty($request->Category))
            {
                    $Category['role_id']=$request->role_id;
                    $Category['title']=$data['Category']['name'];
                    if(!empty($data['Category']['view']))
                    {
                        $Category['view']=$data['Category']['view'];
                    }else
                    {
                        $Category['view']=NULL;
                    }
                    if(!empty($data['Category']['add']))
                    {
                    $Category['add']=$data['Category']['add'];
                    }else
                    {
                        $Category['add']=NULL;
                    }
                    if(!empty($data['Category']['manage']))
                    {
                    $Category['manage']=$data['Category']['manage'];
                    }else
                    {
                        $Category['manage']=NULL;
                    }
                    if(!empty($data['Category']['edit']))
                    {
                    $Category['edit']=$data['Category']['edit'];
                    }else
                    {
                        $Category['edit']=NULL;
                    }
                    if(!empty($data['Category']['delete']))
                    {
                    $Category['delete']=$data['Category']['delete'];
                    }else
                    {
                        $Category['delete']=NULL;
                    }
                $checkcat=\DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['Category']['name'])->first();
                if(empty($checkcat))
                {
                    \DB::table('roles_permissions')->insert($Category);
                }else
                {
                    \DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['Category']['name'])->update($Category);
                }     
            }
            if(!empty($request->subcategory))
            {
                    $subcategory['role_id']=$request->role_id;
                    $subcategory['title']=$data['subcategory']['name'];
                    if(!empty($data['subcategory']['view']))
                    {
                        $subcategory['view']=$data['subcategory']['view'];
                    }else
                    {
                        $subcategory['view']=NULL;
                    }
                    if(!empty($data['subcategory']['add']))
                    {
                    $subcategory['add']=$data['subcategory']['add'];
                    }else
                    {
                        $subcategory['add']=NULL;
                    }
                    if(!empty($data['subcategory']['manage']))
                    {
                    $subcategory['manage']=$data['subcategory']['manage'];
                    }else
                    {
                        $subcategory['manage']=NULL;
                    }
                    if(!empty($data['subcategory']['edit']))
                    {
                    $subcategory['edit']=$data['subcategory']['edit'];
                    }else
                    {
                        $subcategory['edit']=NULL;
                    }
                    if(!empty($data['subcategory']['delete']))
                    {
                    $subcategory['delete']=$data['subcategory']['delete'];
                    }else
                    {
                        $subcategory['delete']=NULL;
                    }
                $checksub=\DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['subcategory']['name'])->first();
                if(empty($checksub))
                {
                    \DB::table('roles_permissions')->insert($subcategory);
                }else
                {
                    \DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['subcategory']['name'])->update($subcategory);
                }     
            }
            if(!empty($request->Videos))
            {
                    $Videos['role_id']=$request->role_id;
                   $Videos['title']=$data['Videos']['name'];
                    if(!empty($data['Videos']['view']))
                    {
                        $Videos['view']=$data['Videos']['view'];
                    }else
                    {
                        $Videos['view']=NULL;
                    }
                    if(!empty($data['Videos']['add']))
                    {
                    $Videos['add']=$data['Videos']['add'];
                    }else
                    {
                        $Videos['add']=NULL;
                    }
                    if(!empty($data['Videos']['manage']))
                    {
                    $Videos['manage']=$data['Videos']['manage'];
                    }else
                    {
                        $Videos['manage']=NULL;
                    }
                    if(!empty($data['Videos']['edit']))
                    {
                    $Videos['edit']=$data['Videos']['edit'];
                    }else
                    {
                        $Videos['edit']=NULL;
                    }
                    if(!empty($data['Videos']['delete']))
                    {
                    $Videos['delete']=$data['Videos']['delete'];
                    }else
                    {
                        $Videos['delete']=NULL;
                    }
                $checkv=\DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['Videos']['name'])->first();
                if(empty($checkv))
                {
                    \DB::table('roles_permissions')->insert($Videos);
                }else
                {
                    \DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['Videos']['name'])->update($Videos);
                }    
            }
            if(!empty($request->Poll))
            {
                    $Poll['role_id']=$request->role_id;
                    $Poll['title']=$data['Poll']['name'];
                    if(!empty($data['Poll']['view']))
                    {
                        $Poll['view']=$data['Poll']['view'];
                    }else
                    {
                        $Poll['view']=NULL;
                    }
                    if(!empty($data['Poll']['add']))
                    {
                    $Poll['add']=$data['Poll']['add'];
                    }else
                    {
                        $Poll['add']=NULL;
                    }
                    if(!empty($data['Poll']['manage']))
                    {
                    $Poll['manage']=$data['Poll']['manage'];
                    }else
                    {
                        $Poll['manage']=NULL;
                    }
                    if(!empty($data['Poll']['edit']))
                    {
                    $Poll['edit']=$data['Poll']['edit'];
                    }else
                    {
                        $Poll['edit']=NULL;
                    }
                    if(!empty($data['Poll']['delete']))
                    {
                    $Poll['delete']=$data['Poll']['delete'];
                    }else
                    {
                        $Poll['delete']=NULL;
                    }
                $checkpoll=\DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['Poll']['name'])->first();
                if(empty($checkpoll))
                {
                    \DB::table('roles_permissions')->insert($Poll);
                }else
                {
                    \DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['Poll']['name'])->update($Poll);
                }    
            }
            if(!empty($request->Content))
            {
                    $Content['role_id']=$request->role_id;
                    $Content['title']=$data['Content']['name'];
                    if(!empty($data['Content']['view']))
                    {
                        $Content['view']=$data['Content']['view'];
                    }else
                    {
                        $Content['view']=NULL;
                    }
                    if(!empty($data['Content']['add']))
                    {
                    $Content['add']=$data['Content']['add'];
                    }else
                    {
                        $Content['add']=NULL;
                    }
                    if(!empty($data['Content']['edit']))
                    {
                    $Content['edit']=$data['Content']['edit'];
                    }else
                    {
                        $Content['edit']=NULL;
                    }
                $checkcon=\DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['Content']['name'])->first();
                if(empty($checkcon))
                {
                    \DB::table('roles_permissions')->insert($Content);
                }else
                {
                    \DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['Content']['name'])->update($Content);
                }    
            }
            if(!empty($request->Faq))
            {
                    $Faq['role_id']=$request->role_id;
                    $Faq['title']=$data['Faq']['name'];
                    if(!empty($data['Faq']['view']))
                    {
                        $Faq['view']=$data['Faq']['view'];
                    }else
                    {
                        $Faq['view']=NULL;
                    }
                    if(!empty($data['Faq']['add']))
                    {
                    $Faq['add']=$data['Faq']['add'];
                    }else
                    {
                        $Faq['add']=NULL;
                    }
                    if(!empty($data['Faq']['manage']))
                    {
                    $Faq['manage']=$data['Faq']['manage'];
                    }else
                    {
                        $Faq['manage']=NULL;
                    }
                    if(!empty($data['Faq']['edit']))
                    {
                    $Faq['edit']=$data['Faq']['edit'];
                    }else
                    {
                        $Faq['edit']=NULL;
                    }
                    if(!empty($data['Faq']['delete']))
                    {
                    $Faq['delete']=$data['Faq']['delete'];
                    }else
                    {
                        $Faq['delete']=NULL;
                    }
                $checkFaq=\DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['Faq']['name'])->first();
                if(empty($checkFaq))
                {
                    \DB::table('roles_permissions')->insert($Faq);
                }else
                {
                    \DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['Faq']['name'])->update($Faq);
                }  
            }
            if(!empty($request->email))
            {
                    $email['role_id']=$request->role_id;
                    $email['title']=$data['email']['name'];
                    if(!empty($data['email']['view']))
                    {
                        $email['view']=$data['email']['view'];
                    }else
                    {
                        $email['view']=NULL;
                    }
                    if(!empty($data['email']['add']))
                    {
                    $email['add']=$data['email']['add'];
                    }else
                    {
                        $email['add']=NULL;
                    }
                    if(!empty($data['email']['edit']))
                    {
                    $email['edit']=$data['email']['edit'];
                    }else
                    {
                        $email['edit']=NULL;
                    }
                $checkemail=\DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['email']['name'])->first();
                if(empty($checkemail))
                {
                    \DB::table('roles_permissions')->insert($email);
                }else
                {
                    \DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['email']['name'])->update($email);
                }
            }
            if(!empty($request->manage))
            {
                    $manage['role_id']=$request->role_id;
                    $manage['title']=$data['manage']['name'];
                    if(!empty($data['manage']['view']))
                    {
                        $manage['view']=$data['manage']['view'];
                    }else
                    {
                        $manage['view']=NULL;
                    }
                    if(!empty($data['manage']['manage']))
                    {
                    $manage['manage']=$data['manage']['manage'];
                    }else
                    {
                        $manage['manage']=NULL;
                    }
                $checkmanage=\DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['manage']['name'])->first();
                if(empty($checkmanage))
                {
                    \DB::table('roles_permissions')->insert($manage);
                }else
                {
                    \DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['manage']['name'])->update($manage);
                }
            }
            if(!empty($request->report))
            {
                    $report['role_id']=$request->role_id;
                    $report['title']=$data['report']['name'];
                    if(!empty($data['report']['view']))
                    {
                        $report['view']=$data['report']['view'];
                    }else
                    {
                        $report['view']=NULL;
                    }
                    if(!empty($data['report']['manage']))
                    {
                    $report['manage']=$data['report']['manage'];
                    }else
                    {
                        $report['manage']=NULL;
                    }
                    if(!empty($data['report']['delete']))
                    {
                    $report['delete']=$data['report']['delete'];
                    }else
                    {
                        $report['delete']=NULL;
                    }
                $checkreport=\DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['report']['name'])->first();
                if(empty($checkreport))
                {
                    \DB::table('roles_permissions')->insert($report);
                }else
                {
                    \DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['report']['name'])->update($report);
                }
                    
            }

            if(!empty($request->comment))
            {
                    $report['role_id']=$request->role_id;
                    $report['title']=$data['comment']['name'];
                    if(!empty($data['comment']['view']))
                    {
                        $report['view']=$data['comment']['view'];
                    }else
                    {
                        $report['view']=NULL;
                    }
                    if(!empty($data['comment']['manage']))
                    {
                    $report['manage']=$data['comment']['manage'];
                    }else
                    {
                        $report['manage']=NULL;
                    }
                    if(!empty($data['comment']['delete']))
                    {
                    $report['delete']=$data['comment']['delete'];
                    }else
                    {
                        $report['delete']=NULL;
                    }
                $checkreport=\DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['comment']['name'])->first();
                if(empty($checkreport))
                {
                    \DB::table('roles_permissions')->insert($report);
                }else
                {
                    \DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['comment']['name'])->update($report);
                }
                    
            }
            if(!empty($request->message))
            {
                    $report['role_id']=$request->role_id;
                    $report['title']=$data['message']['name'];
                    if(!empty($data['message']['manage']))
                    {
                    $report['manage']=$data['message']['manage'];
                    }else
                    {
                        $report['manage']=NULL;
                    }
                $checkreport=\DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['message']['name'])->first();
                if(empty($checkreport))
                {
                    \DB::table('roles_permissions')->insert($report);
                }else
                {
                    \DB::table('roles_permissions')->where('role_id',$request->role_id)->where('title',$data['message']['name'])->update($report);
                }
                    
            }
            
            
            return redirect()->back()->with('success','Permission saved successfully');
            
        }else
        {

            $userrole=Role::where('name',$name)->first();
            $home=\DB::table('roles_permissions')->where('role_id',$userrole->id)->where('title','Home')->first();
            $Community=\DB::table('roles_permissions')->where('role_id',$userrole->id)->where('title','Community')->first();
            $Post=\DB::table('roles_permissions')->where('role_id',$userrole->id)->where('title','Post')->first();
            $Category=\DB::table('roles_permissions')->where('role_id',$userrole->id)->where('title','Category')->first();
            $subcategory=\DB::table('roles_permissions')->where('role_id',$userrole->id)->where('title','subcategory')->first();
            $Videos=\DB::table('roles_permissions')->where('role_id',$userrole->id)->where('title','Videos')->first();
            $Poll=\DB::table('roles_permissions')->where('role_id',$userrole->id)->where('title','Poll')->first();
            $Content=\DB::table('roles_permissions')->where('role_id',$userrole->id)->where('title','Content')->first();
            $Faq=\DB::table('roles_permissions')->where('role_id',$userrole->id)->where('title','Faq')->first();
            $email=\DB::table('roles_permissions')->where('role_id',$userrole->id)->where('title','email')->first();
            $managecommunity=\DB::table('roles_permissions')->where('role_id',$userrole->id)->where('title','manage community')->first();
            $postreport=\DB::table('roles_permissions')->where('role_id',$userrole->id)->where('title','post report')->first();
            $commentreport=\DB::table('roles_permissions')->where('role_id',$userrole->id)->where('title','comment report')->first();
            $usermsg=\DB::table('roles_permissions')->where('role_id',$userrole->id)->where('title','user messages')->first();
            return view('admin.users.user_permission',compact('userrole','home','Community','Post','Category','subcategory','Videos','Poll','Content','Faq','email','managecommunity','postreport','commentreport','usermsg'));
        }
        
    }

    public function usermessages(Request $request)
    {
        $messages=\DB::table('user_messages')->leftJoin('users','users.id','user_messages.user_id')->select('users.name','users.email','user_messages.*')->get();
        return view('admin.users.user_messages')->with(['messages'=>$messages]);
    }


}
