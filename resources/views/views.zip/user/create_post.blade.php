@extends('user.layout.app')
@section('content')
<style type="text/css">
	.drop-zone {
  /*max-width: 800px;*/
  height: 200px;
  padding: 25px;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  font-family: "Quicksand", sans-serif;
  font-weight: 500;
  font-size: 20px;
  cursor: pointer;
  color: #cccccc;
  border: 4px dashed #009578;
  border-radius: 10px;
}

.drop-zone--over {
  border-style: solid;
}

.drop-zone__input {
  display: none;
}

.drop-zone__thumb {
  width: 100%;
  height: 100%;
  border-radius: 10px;
  overflow: hidden;
  background-color: #cccccc;
  background-size: cover;
  position: relative;
}

.drop-zone__thumb::after {
  content: attr(data-label);
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  padding: 5px 0;
  color: #ffffff;
  background: rgba(0, 0, 0, 0.75);
  font-size: 14px;
  text-align: center;
}
.select2-search__field
{
	width: 1000px !important;
}
</style>
<div class="main-wrapper">
   <div class="container">
	 
	   <div class="createnow-sec">
	   
	    <div class="create-btns">
		  <a href="{{route('create.post')}}" class="create-active">Create a Post</a>   
		  <a href="{{route('create.poll')}}">Create a Poll</a> 
		</div>
	   <form method="post" action="{{route('create.post')}}" enctype="multipart/form-data" id="postform">
	   	@csrf
		<div class="inner-createnow">
		  <div class="top-innercreate">
			 <div class="row">
			  
				 <div class="col-md-3 col-sm-6">
				   <div class="form-group createpost-field">
					<label>My Communities</label>
					<select id="community-type"  class="form-control" name="community_id" required="">
						<option value="">Select Community</option>
						@if(!empty($community))
						@foreach($community as $comm)
						<option value="{{$comm->id}}"@if(!empty($comm) && $comm->title==$comm->title) selected @endif>{{$comm->title}}</option>
						@endforeach
						@endif
					</select>
					<input type="hidden" name="" id="commall" value="{{(!empty($community[0])) ? $community[0] :''}}">
						
					<span id="comtype" style="display: none;"></span>
				  </div>
				 </div>
				 
				 <div class="col-md-3 col-sm-6">
				   <div class="create-addpost">
					<h4>Add to your post</h4> 
					 
					<div class="create-media">
					  <img class="media-pic" src="{{asset('public/images/image-ico.png')}}" alt="" title="Add image">
					  <img class="media-pic" src="{{asset('public/images/create-video-ico.png')}}" alt="" title="Add video">
					  <img class="media-pic" src="{{asset('public/images/mic-ico.png')}}" alt="" title="Add audio">
					  <input class="file-upload" name="media" type="file" accept="audio/*,video/*,image/*" capture="camera"  style="display: none;" id="file" onchange="previewimg(this)"/>	
					  <input type="file" accept="image/*;capture=camera">
					</div>
				   </div>
				 </div>
			  
			 </div>
			  
			  <div class="form-group">
			  	<input type="text" name="title" class="form-control" placeholder="Enter title" id="tiletxt">
			  	<span id="textpost" style="display: none;"></span>
			  </div>
			  
			 <div class="editor-sec" id="editor-sec">
			   <textarea class="full-featured-non-premium" name="post" maxlength="400" id="postid"></textarea>
			   <span id="postcontnt" style="float: right;"></span>
			   <span id="words-max" style="margin-top: 5px;color: red;">Maximum words 400</span>
			 </div>
			 @if(!empty($alluser) && count($alluser)>0)
			 <p>Tag People</p>
			 <div class="form-group">
			 <select data-placeholder="Begin typing a name to filter..." multiple class="form-control select2" name="tags[]" id="cmbIdioma" style="width: 100%!important;">
			 <!-- <select multiple class="form-control multiselect" name="tags[]"> -->
			    <option value=""></option>
			   
			    @foreach($alluser as $user)
			    <option value="{{$user->id}}" data-img="@if(!empty($user->image)) {{asset('public/user/images/'.$user->image)}} @else {{asset('public/images/user.png')}} @endif">{{$user->name}}</option>
			    @endforeach
			   
			  </select>

			</div>
			 @endif

			 <div  id="imgsec" style="display: none;">
				    <span class="drop-zone__prompt"></span>
				   
				    <img src="" id="blah" style="width:300px;height:150px;display: none;">
						  		<video width="240" height="160" controls style="display: none;" id="videoid">
							  <source src="" type="video/mp4">
							  <source src="" type="video/ogg">
							Your browser does not support the video tag.
							</video> 
						  		<audio controls style="display: none;" id="audid">
							  <source src="" type="audio/ogg">
							  <source src="" type="audio/mpeg">
							Your browser does not support the audio element.
							</audio> 
			   </div> 
			
			<div class="form-group mb-1 mt-4 submit-col text-md-right">
			  <button type="submit" class="common-btn" id="postuser">Post</button>
			</div>
			  
		  </div>   
		   </form>
		   
		</div>   
	   
	   </div>
	   
	</div>	   
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet"/>

<script type="text/javascript">
	$("#cmbIdioma").select2({
		width: '100%',
		 minimumResultsForSearch: Infinity,
	templateResult: function (idioma) {

		if(idioma.text!='' && idioma.id!='')
		{
			var img = $(idioma.element).attr('data-img');
		   // console.log(img);
		  	var $span = $("<span><img src="+img+" style='width:30px;height:30px;'/> " + idioma.text + "</span>");
		  	return $span;
		}
		
  },
	templateSelection: function (idioma) {
		var img = $(idioma.element).attr('data-img');
  	var $span = $("<span><img src="+img+" style='width:30px;height:30px;'/> " + idioma.text + "</span>");
  	return $span;
  },
  formatNoMatches: function () {
  return "No Results Found";
  }
});
</script>
@endsection