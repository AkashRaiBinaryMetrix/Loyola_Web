@extends('user.layout.app')
@section('content')
<style type="text/css">
	.drop-zone {
  /*max-width: 800px;*/
  height: 200px;
  padding: 25px;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  font-family: "Quicksand", sans-serif;
  font-weight: 500;
  font-size: 20px;
  cursor: pointer;
  color: #cccccc;
  border: 4px dashed #009578;
  border-radius: 10px;
}

.drop-zone--over {
  border-style: solid;
}

.drop-zone__input {
  display: none;
}

.drop-zone__thumb {
  width: 100%;
  height: 100%;
  border-radius: 10px;
  overflow: hidden;
  background-color: #cccccc;
  background-size: cover;
  position: relative;
}

.drop-zone__thumb::after {
  content: attr(data-label);
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  padding: 5px 0;
  color: #ffffff;
  background: rgba(0, 0, 0, 0.75);
  font-size: 14px;
  text-align: center;
}
.tox-notification__body
{
	display: none;
}
.tox-notification__icon
{
	display: none;
}
.tox-notification
{
	display: none;
}
.tox-notification__dismiss
{
	display: none;
}
.tox-notifications-container
{
	display: none;
}
</style>
<div class="main-wrapper">
   <div class="container">
	 
	   <div class="createnow-sec">
	   
	    <!-- <div class="create-btns">
		  <a href="{{route('create.post')}}" class="create-active">Create a Post</a>   
		  <a href="{{route('create.poll')}}">Create a Poll</a> 
		</div> -->
	   <form method="post" action="{{route('edit.post',$id)}}" enctype="multipart/form-data" id="postform">
	   	@csrf
		<div class="inner-createnow">
		  <div class="top-innercreate">
			 <div class="row">
			  
				 <div class="col-md-3 col-sm-6">
				   <div class="form-group createpost-field">
					<label>My Communities</label>
					<select id="community-type"  class="form-control" name="community_id" required="">
						<option value="">Select Community</option>
						@if(!empty($community))
						@foreach($community as $comm)
						<option value="{{$comm->id}}"@if($post->community_id==$comm->id) selected @endif>{{$comm->title}}</option>
						@endforeach
						@endif
					</select>
					<span id="comtype" style="display: none;"></span>
				  </div>
				 </div>
				 
				 <div class="col-md-3 col-sm-6">
				   <div class="create-addpost">
					<h4>Add to your post</h4> 
					 
					<div class="create-media">
					  <img class="media-pic" src="{{asset('public/images/image-ico.png')}}" alt="" title="Add image">
					  <img class="media-pic" src="{{asset('public/images/create-video-ico.png')}}" alt="" title="Add video">
					  <img class="media-pic" src="{{asset('public/images/mic-ico.png')}}" alt="" title="Add audio">
					  <input class="file-upload" name="media" type="file" accept="audio/*,video/*,image/*" style="display: none;" id="file" onchange="previewimg(this)"/>	
					</div>
					   
				   </div>
				 </div>
			  
			 </div>
			  
			  <div class="form-group">
			  	<input type="text" name="title" class="form-control" placeholder="Enter title" id="tiletxt" value="{{$post->title}}">
			  	<span id="textpost" style="display: none;"></span>
			  </div>
			  <textarea class="full-featured-non-premium" name="post">{!!$postdata!!}</textarea>
			 
				 
			  <div  id="imgsec" style="display: none;">
				    <span class="drop-zone__prompt"></span>
				   
				    <img src="" id="blah" style="display: none;max-height: 200px;">
						  		<video width="320" height="240" controls style="display: none;" id="videoid">
							  <source src="" type="video/mp4">
							  <source src="" type="video/ogg">
							Your browser does not support the video tag.
							</video> 
						  		<audio controls style="display: none;" id="audid">
							  <source src="" type="audio/ogg">
							  <source src="" type="audio/mpeg">
							Your browser does not support the audio element.
							</audio> 
			   </div>
			   <div id="postsec">
			   @if(!empty($post->media))
		   			@if($extension[1]=='jpg' || $extension[1]=='jpeg' || $extension[1]=='png')
		   			
					  	<img src="{{asset('public/post/'.$post->media)}}" style="max-height: 200px;">
					  	@elseif($extension[1]=='mp4')
					  		<video width="320" height="240" controls>
						  <source src="{{asset('public/post/'.$post->media)}}" type="video/mp4">
						  <source src="{{asset('public/post/'.$post->media)}}" type="video/ogg">
						Your browser does not support the video tag.
						</video> 
					  	@elseif($extension[1]=='ogg')
					  		<audio controls>
						  <source src="{{asset('public/post/'.$post->media)}}" type="audio/ogg">
						  <source src="{{asset('public/post/'.$post->media)}}" type="audio/mpeg">
						Your browser does not support the audio element.
						</audio>
						
					@endif
			   @endif
			   </div> 
			 <!-- <div class="editor-sec" id="editor-sec">
			   <textarea id="full-featured-non-premium" name="post"></textarea>
			   <span id="postcontnt"></span>
			 </div>  -->
			
			<div class="form-group mb-1 mt-4 submit-col text-md-right">
			  <button type="submit" class="common-btn" id="postuser">Post</button>
			</div>
			  
		  </div>   
		   </form>
		   
		</div>   
	   
	   </div>
	   
	</div>	   
</div>
@endsection