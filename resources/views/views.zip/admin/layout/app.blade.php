<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Welcome To | If I were</title>
    <!-- Favicon-->
    <link rel="icon" href="favicon.ico" type="{{asset('public/images/favicon.png')}}">
    <link rel="shortcut icon" href="{{asset('public/images/favicon.png')}}">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <!-- Bootstrap Core Css -->
    <link href="{{ asset('public/admin/plugins/bootstrap/css/bootstrap.css') }}" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="{{ asset('public/admin/plugins/node-waves/waves.css') }}" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="{{ asset('public/admin/plugins/animate-css/animate.css') }}" rel="stylesheet" />

    <!-- JQuery DataTable Css -->
    <link href="{{ asset('public/admin/plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css') }}" rel="stylesheet">

    <!-- Custom Css -->
    <link href="{{ asset('public/admin/css/style.css') }}" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="{{ asset('public/admin/css/themes/all-themes.css') }}" rel="stylesheet" />
</head>

<body class="theme-red">
    <!-- Page Loader -->
    <!-- <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div> -->
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
    <div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">search</i>
        </div>
        <input type="text" placeholder="START TYPING...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
    <!-- #END# Search Bar -->
    <!-- Top Bar -->
    @php
     $user=\Session::get('admin');
    
     if(!empty($user))
     {

        $email=DB::table('users')->where('id',$user->id)->first();
     }else
     {
        $email='';
     }
    @endphp
    <nav class="navbar">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="javascript:void(0);" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false"></a>
                <a href="javascript:void(0);" class="bars"></a>
                <a class="navbar-brand" href="javascript:void(0)">Admin</a>
            </div>
            
        </div>
    </nav>
    <!-- #Top Bar -->
    
    <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- User Info -->
            <div class="user-info">
                <div class="image">
                    <img src="@if(!empty($email->profile_pic)) {{ asset('public/'.$email->profile_pic) }} @else {{ asset('public/images/user.png') }} @endif" width="48" height="48" alt="User" />
                </div>
                <div class="info-container">
                    <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">{{$email->name}}</div>
                    <div class="email">{{$email->email}}</div>
                    <div class="btn-group user-helper-dropdown">
                        <i class="material-icons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">keyboard_arrow_down</i>
                        <ul class="dropdown-menu pull-right">
                            <li><a href="{{route('admin.profile')}}"><i class="material-icons">person</i>Profile</a></li>
                            <!-- <li><a href="javascript:void(0);"><i class="material-icons">group</i>Followers</a></li>
                            <li><a href="javascript:void(0);"><i class="material-icons">shopping_cart</i>Sales</a></li>
                            <li><a href="javascript:void(0);"><i class="material-icons">favorite</i>Likes</a></li> -->
                            <li role="separator" class="divider"></li>
                            <li><a href="{{route('admin.logout')}}"><i class="material-icons">input</i>Sign Out</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- #User Info -->
            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                    @php 
                    $rolepermission=DB::table('roles_permissions')->where('role_id',$user->role_id)->where('title','Home')->first();
                    @endphp
                    <li class="header">MAIN NAVIGATION</li>
                    @if(!empty($user) && !empty($rolepermission) && $rolepermission->view==1 || $user->role_id==1)
                    <li class="@if(\Request::route()->getName()=='admin.home') active @endif">
                        <a href="{{route('admin.home')}}">
                            <i class="material-icons">home</i>
                            <span>Home</span>
                        </a>
                    </li>
                    @endif
                    @php 
                    $permissionCommunity=DB::table('roles_permissions')->where('role_id',$user->role_id)->where('title','Community')->first();
                    @endphp
                    @if(!empty($user) && !empty($permissionCommunity) && $permissionCommunity->view==1 || $user->role_id==1)
                    <li class="@if(\Request::route()->getName()=='admin.add.community' || \Request::route()->getName()=='admin.manage.community') active @endif">
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">assignment</i>
                            <span>Community</span>
                        </a>
                        <ul class="ml-menu">
                            @if(!empty($user) && !empty($permissionCommunity) && $permissionCommunity->add==1 || $user->role_id==1)
                            <li class="@if(\Request::route()->getName()=='admin.add.community') active @endif">
                                <a href="{{route('admin.add.community')}}">Add Community</a>
                            </li>
                            @endif
                            @if(!empty($user) && !empty($permissionCommunity) && $permissionCommunity->manage==1 || $user->role_id==1)
                            <li class="@if(\Request::route()->getName()=='admin.manage.community') active @endif">
                                <a href="{{route('admin.manage.community')}}">Manage Community</a>
                            </li>
                            @endif
                        </ul>
                    </li>
                    @endif
                    @php 
                    $permissionPost=DB::table('roles_permissions')->where('role_id',$user->role_id)->where('title','Post')->first();
                    @endphp
                    @if(!empty($user) && !empty($permissionPost) && $permissionPost->view==1 || $user->role_id==1)
                    <li class="@if(\Request::route()->getName()=='admin.add.post' || \Request::route()->getName()=='admin.manage.post') active @endif">
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">pages</i>
                            <span>Post</span>
                        </a>
                        <ul class="ml-menu">
                            @if(!empty($user) && !empty($permissionPost) && $permissionPost->add==1 || $user->role_id==1)
                            <li class="@if(\Request::route()->getName()=='admin.add.post') active @endif">
                                <a href="{{route('admin.add.post')}}">Add Post</a>
                            </li>
                            @endif
                            @if(!empty($user) && !empty($permissionPost) && $permissionPost->manage==1 || $user->role_id==1)
                            <li class="@if(\Request::route()->getName()=='admin.manage.post') active @endif">
                                <a href="{{route('admin.manage.post')}}">Manage Post</a>
                            </li>
                            @endif
                        </ul>
                    </li>
                    @endif
                    @php 
                    $permissionCategory=DB::table('roles_permissions')->where('role_id',$user->role_id)->where('title','Category')->first();
                    @endphp
                    @if(!empty($user) && !empty($permissionCategory) && $permissionCategory->view==1 || $user->role_id==1)
                    <li class="@if(\Request::route()->getName()=='admin.add.category' || \Request::route()->getName()=='admin.manage.category' || \Request::route()->getName()=='admin.edit.subcategory') active @endif">
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">widgets</i>
                            <span>Category</span>
                        </a>
                        <ul class="ml-menu">
                             @if(!empty($user) && !empty($permissionCategory) && $permissionCategory->add==1 || $user->role_id==1)
                            <li class="@if(\Request::route()->getName()=='admin.add.category') active @endif">
                                <a href="{{route('admin.add.category')}}">Add Category</a>
                            </li>
                            @endif
                             @if(!empty($user) && !empty($permissionCategory) && $permissionCategory->manage==1 || $user->role_id==1)
                            <li class="@if(\Request::route()->getName()=='admin.manage.category') active @endif">
                                <a href="{{route('admin.manage.category')}}">Manage Category</a>
                            </li>
                            @endif
                        </ul>
                    </li>
                    @endif
                    @php 
                    $permissionsubcategory=DB::table('roles_permissions')->where('role_id',$user->role_id)->where('title','subcategory')->first();
                    @endphp
                    @if(!empty($user) && !empty($permissionsubcategory) && $permissionsubcategory->view==1 || $user->role_id==1)
                    <li class="@if(\Request::route()->getName()=='admin.add.subcategory' || \Request::route()->getName()=='admin.manage.subcategory' || \Request::route()->getName()=='admin.edit.subcategory') active @endif">
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">view_list</i>
                            <span>Sub Category</span>
                        </a>
                        <ul class="ml-menu">
                            @if(!empty($user) && !empty($permissionsubcategory) && $permissionsubcategory->add==1 || $user->role_id==1)
                            <li class="@if(\Request::route()->getName()=='admin.add.subcategory') active @endif">
                                <a href="{{route('admin.add.subcategory')}}">Add Sub Category</a>
                            </li>
                            @endif
                            @if(!empty($user) && !empty($permissionsubcategory) && $permissionsubcategory->manage==1 || $user->role_id==1)
                            <li class="@if(\Request::route()->getName()=='admin.manage.subcategory') active @endif">
                                <a href="{{route('admin.manage.subcategory')}}">Manage Sub Category</a>
                            </li>
                            @endif
                        </ul>
                    </li>
                    @endif
                    @php 
                    $permissionVideos=DB::table('roles_permissions')->where('role_id',$user->role_id)->where('title','Videos')->first();
                    @endphp
                    @if(!empty($user) && !empty($permissionVideos) && $permissionVideos->view==1 || $user->role_id==1)
                    <li class="@if(\Request::route()->getName()=='admin.video.add' || \Request::route()->getName()=='admin.video.manage' || \Request::route()->getName()=='admin.video.edit') active @endif">
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">perm_media</i>
                            <span>Videos</span>
                        </a>
                        <ul class="ml-menu">
                            @if(!empty($user) && !empty($permissionVideos) && $permissionVideos->add==1 || $user->role_id==1)
                            <li class="@if(\Request::route()->getName()=='admin.video.add') active @endif">
                                <a href="{{route('admin.video.add')}}">Add Video</a>
                            </li>
                            @endif
                            @if(!empty($user) && !empty($permissionVideos) && $permissionVideos->delete==1 || $user->role_id==1)
                            <li class="@if(\Request::route()->getName()=='admin.video.manage') active @endif">
                                <a href="{{route('admin.video.manage')}}">Manage Video</a>
                            </li>
                            @endif
                        </ul>
                    </li>
                    @endif
                    @php 
                    $permissionPoll=DB::table('roles_permissions')->where('role_id',$user->role_id)->where('title','Poll')->first();
                    @endphp
                    @if(!empty($user) && !empty($permissionPoll) && $permissionPoll->view==1 || $user->role_id==1)
                    <li class="@if(\Request::route()->getName()=='admin.add.poll' || request()->path()=='admin/poll/manage' || \Request::route()->getName()=='admin.edit.poll') active @endif">
                        <a href="javascri   pt:void(0);" class="menu-toggle">
                            <i class="material-icons">map</i>
                            <span>Poll</span>
                        </a>
                        <ul class="ml-menu">
                            @if(!empty($user) && !empty($permissionPoll) && $permissionPoll->add==1 || $user->role_id==1)
                            <li class="@if(\Request::route()->getName()=='admin.add.poll') active @endif">
                                <a href="{{route('admin.add.poll')}}">Create Poll</a>
                            </li>
                            @endif
                            @if(!empty($user) && !empty($permissionPoll) && $permissionPoll->manage==1 || $user->role_id==1)
                            <li class="@if(request()->path()=='admin/poll/manage') active @endif">
                                <a href="{{route('admin.manage.poll')}}">Manage Poll</a>
                            </li>
                            @endif
                        </ul>
                    </li>
                    @endif
                    @if($user->role_id==1)
                    <li class="@if(\Request::route()->getName()=='admin.manage.users') active @endif">
                        <a href="{{route('admin.manage.users')}}" class="">
                            <i class="material-icons">group</i>
                            <span>Manage Users</span>
                        </a>
                        <!-- <ul class="ml-menu">
                            <li>
                                <a href="{{route('admin.manage.users')}}">Manage Users</a>
                            </li>
                        </ul> -->
                    </li>
                    @endif
                    @php 
                    $permissionContent=DB::table('roles_permissions')->where('role_id',$user->role_id)->where('title','Content')->first();
                    @endphp
                    @if(!empty($user) && !empty($permissionContent) && $permissionContent->view==1 || $user->role_id==1)
                     <li class="@if(\Request::route()->getName()=='admin.content.about' || \Request::route()->getName()=='admin.content.terms' || \Request::route()->getName()=='admin.content.manage.enquiry' || \Request::route()->getName()=='admin.content.privacy_policy' || \Request::route()->getName()=='admin.content.contactus') active @endif">
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">view_list</i>
                            <span>Content Management</span>
                        </a>
                        <ul class="ml-menu">
                            <li class="@if(\Request::route()->getName()=='admin.content.about') active @endif">
                                <a href="{{route('admin.content.about')}}">About Us</a>
                            </li>
                            <li class="@if(\Request::route()->getName()=='admin.content.terms') active @endif">
                                <a href="{{route('admin.content.terms')}}">Terms & Conditions</a>
                            </li>
                            <li class="@if(\Request::route()->getName()=='admin.content.manage.enquiry') active @endif">
                                <a href="{{route('admin.content.manage.enquiry')}}">Manage Enquiry</a>
                            </li>
                            <li class="@if(\Request::route()->getName()=='admin.content.privacy_policy') active @endif">
                                <a href="{{route('admin.content.privacy_policy')}}">Privacy Policies</a>
                            </li>
                            <li class="@if(\Request::route()->getName()=='admin.content.contactus') active @endif">
                                <a href="{{route('admin.content.contactus')}}">Contact Us</a>
                            </li>
                        </ul>
                    </li>
                    @endif
                    @if($user->role_id==1)
                    <li class="@if(\Request::route()->getName()=='admin.users.role.add' || \Request::route()->getName()=='admin.users.role.manage') active @endif">
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">person</i>
                            <span>User Roles</span>
                        </a>
                        <ul class="ml-menu">
                            <li class="@if(\Request::route()->getName()=='admin.users.role.add') active @endif">
                                <a href="{{route('admin.users.role.add')}}">Add User Role</a>
                            </li>
                            <li class="@if(\Request::route()->getName()=='admin.users.role.manage') active @endif">
                                <a href="{{route('admin.users.role.manage')}}">Manage User Role</a>
                            </li>
                            </ul>
                        
                    </li>
                    @endif
                    @if($user->role_id==1)
                    <li class="@if(\Request::route()->getName()=='admin.users.permission') active @endif">
                        <a href="{{route('admin.users.permission') }}">
                            <i class="material-icons">update</i>
                            <span>Manage User Permission</span>
                        </a>
                       
                    </li>
                    @endif
                    @php 
                    $permissionFaq=DB::table('roles_permissions')->where('role_id',$user->role_id)->where('title','Faq')->first();
                    @endphp
                    @if(!empty($user) && !empty($permissionFaq) && $permissionFaq->view==1 || $user->role_id==1)
                    <li class="@if(\Request::route()->getName()=='admin.content.faq' || \Request::route()->getName()=='admin.content.managefaq' || \Request::route()->getName()=='admin.content.editfaq') active @endif">
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">layers</i>
                            <span>FAQ</span>
                        </a>
                        <ul class="ml-menu">
                            @if(!empty($user) && !empty($permissionFaq) && $permissionFaq->add==1 || $user->role_id==1)
                            <li class="@if(\Request::route()->getName()=='admin.content.faq') active @endif">
                                <a href="{{route('admin.content.faq')}}">Faq</a>
                            </li>
                            @endif
                            @if(!empty($user) && !empty($permissionFaq) && $permissionFaq->manage==1 || $user->role_id==1)
                            <li class="@if(\Request::route()->getName()=='admin.content.managefaq') active @endif">
                                <a href="{{route('admin.content.managefaq')}}">Manage Faq</a>
                            </li>
                            @endif
                        </ul>
                    </li>
                    @endif
                    @php 
                    $permissionemail=DB::table('roles_permissions')->where('role_id',$user->role_id)->where('title','email')->first();
                    @endphp
                    @if(!empty($user) && !empty($permissionemail) && $permissionemail->view==1 || $user->role_id==1)
                    <li class="@if(\Request::route()->getName()=='admin.email.template.notification' || \Request::route()->getName()=='admin.email.template.welcome' || \Request::route()->getName()=='admin.email.template.forget_password') active @endif">
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">mail</i>
                            <span>Email Template</span>
                        </a>
                        <ul class="ml-menu">
                            <li class="@if(\Request::route()->getName()=='admin.email.template.notification') active @endif">
                                <a href="{{route('admin.email.template.notification')}}">Notifications</a>
                            </li>
                            <li class="@if(\Request::route()->getName()=='admin.email.template.welcome') active @endif">
                                <a href="{{route('admin.email.template.welcome')}}">Welcome Note</a>
                            </li>
                            <li class="@if(\Request::route()->getName()=='admin.email.template.forget_password') active @endif">
                                <a href="{{route('admin.email.template.forget_password')}}">Forgot Your Password</a>
                            </li>
                        </ul>
                    </li>
                    @endif
                    @php 
                    $permissionmanagecommunity=DB::table('roles_permissions')->where('role_id',$user->role_id)->where('title','manage community')->first();
                    @endphp
                    @if(!empty($user) && !empty($permissionmanagecommunity) && $permissionmanagecommunity->view==1 || $user->role_id==1)
                    <li class="@if(\Request::route()->getName()=='admin.community.request') active @endif">
                        <a href="{{route('admin.community.request')}}" >
                            <i class="material-icons">content_copy</i>
                            <span>Manage Community Request</span>
                        </a>
                    </li>
                    @endif
                    @php 
                    $permissionreport=DB::table('roles_permissions')->where('role_id',$user->role_id)->where('title','post report')->first();
                    @endphp
                    @if(!empty($user) && !empty($permissionreport) && $permissionreport->view==1 || $user->role_id==1)
                    <li class="@if(\Request::route()->getName()=='admin.post.report') active @endif">
                        <a href="{{route('admin.post.report')}}" >
                            <i class="material-icons">pie_chart</i>
                            <span>Posts Report</span>
                        </a>
                    </li>
                    @endif
                    @php 
                    $permissionreport=DB::table('roles_permissions')->where('role_id',$user->role_id)->where('title','comment report')->first();
                    @endphp
                    @if(!empty($user) && !empty($permissionreport) && $permissionreport->view==1 || $user->role_id==1)
                    <li class="@if(\Request::route()->getName()=='admin.comments.report') active @endif">
                        <a href="{{route('admin.comments.report')}}" >
                            <i class="material-icons">text_fields</i>
                            <span>Comment Report</span>
                        </a>
                    </li>
                    @endif
                    @php 
                    $permissionreport=DB::table('roles_permissions')->where('role_id',$user->role_id)->where('title','user messages')->first();
                    @endphp
                    @if(!empty($user) && !empty($permissionreport) && $permissionreport->view==1 || $user->role_id==1)
                    <li class="@if(\Request::route()->getName()=='admin.user.message') active @endif">
                        <a href="{{route('admin.user.message')}}" >
                            <i class="material-icons">mail</i>
                            <span>User Messages</span>
                        </a>
                    </li>
                    @endif
                  
                </ul>
            </div>
            <!-- #Menu -->
            <!-- Footer -->
           
            <!-- #Footer -->
        </aside>
        <!-- #END# Left Sidebar -->
    </section>

   @yield('content')

    <script src="{{ asset('public/admin/plugins/jquery/jquery.min.js') }}"></script>

    <!-- Bootstrap Core Js -->
    <script src="{{ asset('public/admin/plugins/bootstrap/js/bootstrap.js') }}"></script>

    <!-- Select Plugin Js -->
    

    <!-- Slimscroll Plugin Js -->
    <script src="{{ asset('public/admin/plugins/jquery-slimscroll/jquery.slimscroll.js') }}"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="{{ asset('public/admin/plugins/node-waves/waves.js') }}"></script>

    <!-- Jquery DataTable Plugin Js -->
    <script src="{{ asset('public/admin/plugins/jquery-datatable/jquery.dataTables.js') }}"></script>
    <script src="{{ asset('public/admin/plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js') }}"></script>
    <script src="{{ asset('public/admin/plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js') }}"></script>
    <script src="{{ asset('public/admin/plugins/jquery-datatable/extensions/export/buttons.flash.min.js') }}"></script>
    <script src="{{ asset('public/admin/plugins/jquery-datatable/extensions/export/jszip.min.js') }}"></script>
    <script src="{{ asset('public/admin/plugins/jquery-datatable/extensions/export/pdfmake.min.js') }}"></script>
    <script src="{{ asset('public/admin/plugins/jquery-datatable/extensions/export/vfs_fonts.js') }}"></script>
    <script src="{{ asset('public/admin/plugins/jquery-datatable/extensions/export/buttons.html5.min.js') }}"></script>
    <script src="{{ asset('public/admin/plugins/jquery-datatable/extensions/export/buttons.print.min.js') }}"></script>

    <!-- Custom Js -->
    <script src="{{ asset('public/admin/js/admin.js') }}"></script>
    <script src="{{ asset('public/admin/js/pages/tables/jquery-datatable.js') }}"></script>

    <!-- Demo Js -->
    <script src="{{ asset('public/admin/js/demo.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
</body>
@include('admin.layout.admin_script')
</html>
