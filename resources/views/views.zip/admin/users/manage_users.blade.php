 @extends('admin.layout.app')
 @section('content')
 <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>Manage Users</h2>
                 <a href="{{route('admin.add.users')}}" class="btn btn-success" style="margin: 12px;float: right;"><i class="fa fa-plus" style="padding-right: 3px;"></i>Add New User</a>
                @if ($message = Session::get('error'))
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong>{{ $message }}</strong>
                </div>
                @endif
                @if ($message = Session::get('success'))
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong>{{ $message }}</strong>
                </div>
                @endif
            </div>
            <!-- Basic Table -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">

                        <div class="header">

                            <h2>
                                All Users
                            </h2>


                            <!-- <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);">Action</a></li>
                                        <li><a href="javascript:void(0);">Another action</a></li>
                                        <li><a href="javascript:void(0);">Something else here</a></li>
                                    </ul>
                                </li>
                            </ul> -->
                        </div>
                        <div class="body" style="overflow: scroll;">

                            <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                <thead> 
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>User Role</th>
                                        <th>Registration Date</th>
                                        <th>Action</th>
                                        <th>Registration Status</th>
                                        <th>User Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($users as $key=>$user)
                                    @php
                                    $status1=encrypt('reject');
                                    $status2=encrypt('deactive');
                                    $status3=encrypt('approve');
                                    $status4=encrypt('active');

                                    @endphp
                                    <tr>
                                        <th scope="row">{{$key+1}}</th>
                                        <td>{{$user->name}}</td>
                                        <td>{{$user->email}}</td>
                                        <td>{{$user->role_name}}</td>
                                        <td>{{date('d-m-Y h:m:ia',strtotime($user->created_at))}}</td> 
                                        <td>
                                            <a href="{{route('admin.edit.users',encrypt($user->id))}}" class="btn btn-success"><i class="fa fa-edit" style="padding-right: 3px;"></i>Edit</a>
                                            <a href="{{url('admin/delete-users/'.encrypt($user->id))}}" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete?')" id="del{{$key+1}}" style="margin-top: 5px;"><i class="fa fa-trash" style="padding-right: 3px;"></i>Delete</a>
                                        </td>
                                        <td> 
                                            <select onchange="regstatus(this,'{{$user->id}}')" class="form-control">
                                                <option value="">Select</option>
                                                <option value="approve"@if($user->reject_status=='1' || is_null($user->reject_status) || $user->user_status==1) selected @endif>Approve</option>
                                                <option value="reject"@if($user->reject_status=='0') selected @endif>Reject</option>
                                            </select>
                                        </td>
                                        <td>
                                           
                                            <select onchange="regstatus(this,'{{$user->id}}')" class="form-control">
                                                <option value="">Select</option>
                                                <option value="active"@if($user->user_status=='1' || is_null($user->user_status) || $user->reject_status=='1') selected @endif>Active</option>
                                                <option value="deactive"@if($user->user_status=='0' ||$user->reject_status=='0') selected @endif>Deactive</option>
                                            </select>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
</section>

@endsection